<?php
/**
 * api/inventory.php
 * GET  /inventory.php               → list products (with stock + batch info)
 * GET  /inventory.php?id=N          → single product detail
 * POST /inventory.php               → add / edit / delete product
 *                                     POST /inventory.php?action=categories
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/auth_middleware.php';

$authUser = validateToken();
$userId   = $authUser['user_id'];

// ── Categories sub-resource ──────────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'categories') {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $res  = $conn->query("SELECT * FROM categories ORDER BY name ASC");
        $cats = [];
        while ($r = $res->fetch_assoc()) $cats[] = $r;
        echo json_encode(['success' => true, 'categories' => $cats]);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data   = json_decode(file_get_contents('php://input'), true);
        $action = $data['action'] ?? '';

        if ($action === 'add_category') {
            $name = trim($data['name'] ?? '');
            $desc = trim($data['description'] ?? '');
            if (empty($name)) { echo json_encode(['success'=>false,'message'=>'Name required']); exit; }
            $stmt = $conn->prepare("INSERT INTO categories (name,description) VALUES (?,?)");
            $stmt->bind_param("ss", $name, $desc);
            $ok = $stmt->execute(); $stmt->close();
            logActivity($conn, $userId, 'Add Category', "Added category: $name");
            echo json_encode(['success' => $ok]);
            exit;
        }

        if ($action === 'edit_category') {
            $id   = (int)($data['id'] ?? 0);
            $name = trim($data['name'] ?? '');
            $desc = trim($data['description'] ?? '');
            $stmt = $conn->prepare("UPDATE categories SET name=?,description=? WHERE id=?");
            $stmt->bind_param("ssi", $name, $desc, $id);
            $ok = $stmt->execute(); $stmt->close();
            logActivity($conn, $userId, 'Edit Category', "Edited category ID: $id");
            echo json_encode(['success' => $ok]);
            exit;
        }

        if ($action === 'delete_category') {
            $id   = (int)($data['id'] ?? 0);
            $stmt = $conn->prepare("DELETE FROM categories WHERE id=?");
            $stmt->bind_param("i", $id);
            $ok = $stmt->execute(); $stmt->close();
            logActivity($conn, $userId, 'Delete Category', "Deleted category ID: $id");
            echo json_encode(['success' => $ok]);
            exit;
        }
    }
    echo json_encode(['success' => false, 'message' => 'Unknown request']);
    exit;
}

// ── Single product ────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id   = (int)$_GET['id'];
    $stmt = $conn->prepare("
        SELECT p.*, c.name AS category_name,
               COALESCE((
                   SELECT SUM(sb.quantity_base) FROM stock_batches sb
                   WHERE sb.product_id = p.id
                     AND sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
               ),0) AS available_stock
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) { echo json_encode(['success'=>false,'message'=>'Not found']); exit; }

    // batches
    $bStmt = $conn->prepare("
        SELECT * FROM stock_batches WHERE product_id = ? ORDER BY expiration_date ASC
    ");
    $bStmt->bind_param("i", $id);
    $bStmt->execute();
    $bRes    = $bStmt->get_result();
    $batches = [];
    while ($r = $bRes->fetch_assoc()) $batches[] = $r;
    $bStmt->close();

    // units
    $uStmt = $conn->prepare("SELECT * FROM product_units WHERE product_id = ? ORDER BY sort_order");
    $uStmt->bind_param("i", $id);
    $uStmt->execute();
    $uRes  = $uStmt->get_result();
    $units = [];
    while ($r = $uRes->fetch_assoc()) $units[] = $r;
    $uStmt->close();

    echo json_encode(['success'=>true,'product'=>$product,'batches'=>$batches,'units'=>$units]);
    exit;
}

// ── Product list ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $search   = trim($_GET['search'] ?? '');
    $category = (int)($_GET['category_id'] ?? 0);
    $filter   = $_GET['filter'] ?? 'all'; // all | low_stock | near_expiry | expired | out_of_stock

    $having = '';
    switch ($filter) {
        case 'low_stock':
            $having = "HAVING available_stock > 0 AND available_stock <= p.low_stock_threshold"; break;
        case 'near_expiry':
            $having = "HAVING near_expiry_count > 0"; break;
        case 'expired':
            $having = "HAVING expired_count > 0"; break;
        case 'out_of_stock':
            $having = "HAVING available_stock = 0"; break;
    }

    $where = "WHERE 1=1";
    $params = [];
    $types  = '';
    if ($search) { $where .= " AND (p.brand_name LIKE ? OR p.generic_name LIKE ? OR p.barcode LIKE ?)"; $like="%$search%"; $params=[$like,$like,$like]; $types='sss'; }
    if ($category) { $where .= " AND p.category_id = ?"; $params[]=$category; $types.='i'; }

    $sql = "
        SELECT p.*, c.name AS category_name,
               COALESCE((
                   SELECT SUM(sb.quantity_base) FROM stock_batches sb
                   WHERE sb.product_id = p.id
                     AND sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
               ),0) AS available_stock,
               (SELECT COUNT(*) FROM stock_batches sb WHERE sb.product_id = p.id
                AND sb.expiration_date > CURDATE()
                AND sb.expiration_date < DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
                AND sb.quantity_base > 0) AS near_expiry_count,
               (SELECT COUNT(*) FROM stock_batches sb WHERE sb.product_id = p.id
                AND sb.expiration_date <= CURDATE() AND sb.quantity_base > 0) AS expired_count
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        $where
        GROUP BY p.id
        $having
        ORDER BY p.brand_name ASC
        LIMIT 200
    ";

    $stmt = $conn->prepare($sql);
    if ($types) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res      = $stmt->get_result();
    $products = [];
    while ($r = $res->fetch_assoc()) $products[] = $r;
    $stmt->close();

    echo json_encode(['success'=>true,'products'=>$products,'count'=>count($products)]);
    exit;
}

// ── POST: add / edit / delete product ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data   = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';

    // ── ADD PRODUCT ──────────────────────────────────────────────────────────
    if ($action === 'add_product') {
        $brand_name   = trim($data['brand_name'] ?? '');
        $generic_name = trim($data['generic_name'] ?? '');
        $category_id  = (int)($data['category_id'] ?? 0);
        $dosage_form  = trim($data['dosage_form'] ?? '');
        $strength     = trim($data['strength'] ?? '');
        $barcode      = trim($data['barcode'] ?? '') ?: null;
        $base_unit    = trim($data['base_unit'] ?? 'piece');
        $price        = (float)($data['price'] ?? 0);
        $cost         = (float)($data['cost'] ?? 0);
        $threshold    = max(1, (int)($data['low_stock_threshold'] ?? 10));
        $vat_type     = trim($data['vat_type'] ?? 'vatable');
        $purchase_unit   = trim($data['purchase_unit'] ?? $base_unit);
        $conv_factor     = max(1, (int)($data['conversion_factor'] ?? 1));
        $purchase_qty    = (int)($data['purchase_qty'] ?? 0);

        if (empty($brand_name)) {
            echo json_encode(['success' => false, 'message' => 'Product name required']); exit;
        }
        if (!$category_id) {
            echo json_encode(['success' => false, 'message' => 'Category required']); exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO products
                (brand_name, generic_name, category_id, dosage_form, strength,
                 barcode, base_unit, price, cost, low_stock_threshold, vat_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        // s s i s s s s d d i s
        $stmt->bind_param(
            "ssississdis",
            $brand_name, $generic_name, $category_id, $dosage_form, $strength,
            $barcode, $base_unit, $price, $cost, $threshold, $vat_type
        );
        $ok = $stmt->execute();
        $new_id = $conn->insert_id;
        $stmt->close();

        if (!$ok) {
            echo json_encode(['success' => false, 'message' => $conn->error]); exit;
        }

        // Add initial stock batch if purchase_qty > 0
        if ($purchase_qty > 0 && $new_id) {
            $exp_date = date('Y-m-d', strtotime('+1 year'));
            $batch_num = 'BATCH-' . date('Ymd') . '-' . $new_id;
            $qty_base = $purchase_qty * $conv_factor;
            $sb = $conn->prepare("
                INSERT INTO stock_batches
                    (product_id, batch_number, quantity_base, expiration_date, received_unit, received_qty)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $sb->bind_param("isisis", $new_id, $batch_num, $qty_base, $exp_date, $purchase_unit, $purchase_qty);
            $sb->execute();
            $sb->close();
        }

        logActivity($conn, $userId, 'Add Product', "Added product: $brand_name", $new_id);
        echo json_encode(['success' => true, 'id' => $new_id, 'message' => 'Product added successfully']);
        exit;
    }

    // ── ADD CATEGORY (also accepts without ?action=categories in URL) ─────────
    if ($action === 'add_category') {
        $name = trim($data['name'] ?? '');
        $desc = trim($data['description'] ?? '');
        if (empty($name)) {
            echo json_encode(['success' => false, 'message' => 'Category name required']); exit;
        }
        // Duplicate check
        $chk = $conn->prepare("SELECT id FROM categories WHERE name = ? LIMIT 1");
        $chk->bind_param("s", $name);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows > 0) {
            $chk->close();
            echo json_encode(['success' => false, 'message' => "Category \"$name\" already exists"]); exit;
        }
        $chk->close();
        $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $desc);
        $ok = $stmt->execute();
        $stmt->close();
        if ($ok) logActivity($conn, $userId, 'Add Category', "Added category: $name");
        echo json_encode(['success' => $ok, 'message' => $ok ? "Category \"$name\" added" : $conn->error]);
        exit;
    }

    // ── DELETE ───────────────────────────────────────────────────────────────
    if ($action === 'delete_product') {
        $id   = (int)($data['id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM products WHERE id=?");
        $stmt->bind_param("i", $id);
        $ok = $stmt->execute(); $stmt->close();
        if ($ok) logActivity($conn, $userId, 'Delete Product', "Deleted product ID: $id", $id);
        echo json_encode(['success' => $ok]);
        exit;
    }

    // ── EDIT ─────────────────────────────────────────────────────────────────
    if ($action === 'edit_product') {
        $id           = (int)($data['id'] ?? 0);
        $brand_name   = trim($data['brand_name'] ?? '');
        $generic_name = trim($data['generic_name'] ?? '');
        $category_id  = (int)($data['category_id'] ?? 0);
        $base_unit    = trim($data['base_unit'] ?? 'piece');
        $price        = (float)($data['price'] ?? 0);
        $cost         = (float)($data['cost'] ?? 0);
        $threshold    = max(1, (int)($data['low_stock_threshold'] ?? 10));
        $barcode      = trim($data['barcode'] ?? '') ?: null;

        $stmt = $conn->prepare("
            UPDATE products SET brand_name=?,generic_name=?,category_id=?,
            base_unit=?,price=?,cost=?,low_stock_threshold=?,barcode=? WHERE id=?
        ");
        $stmt->bind_param("ssiidddsi", $brand_name,$generic_name,$category_id,
                          $base_unit,$price,$cost,$threshold,$barcode,$id);
        $ok = $stmt->execute(); $stmt->close();
        if ($ok) logActivity($conn, $userId, 'Edit Product', "Edited: $brand_name (ID: $id)", $id);
        echo json_encode(['success' => $ok]);
        exit;
    }

    // ── ADD STOCK BATCH ──────────────────────────────────────────────────────
    if ($action === 'add_stock') {
        $product_id  = (int)($data['product_id'] ?? 0);
        $batch_num   = trim($data['batch_number'] ?? 'BATCH-'.date('Ymd'));
        $qty         = (int)($data['quantity'] ?? 0);
        $expiry      = trim($data['expiration_date'] ?? '');
        $recv_unit   = trim($data['received_unit'] ?? 'piece');
        $recv_qty    = (int)($data['received_qty'] ?? $qty);

        if (!$product_id || $qty <= 0 || empty($expiry)) {
            echo json_encode(['success'=>false,'message'=>'Invalid stock data']); exit;
        }
        $stmt = $conn->prepare("
            INSERT INTO stock_batches (product_id,batch_number,quantity_base,expiration_date,received_unit,received_qty)
            VALUES (?,?,?,?,?,?)
        ");
        $stmt->bind_param("isissi", $product_id,$batch_num,$qty,$expiry,$recv_unit,$recv_qty);
        $ok = $stmt->execute(); $stmt->close();
        if ($ok) logActivity($conn, $userId, 'Add Stock', "Added $qty units to product ID: $product_id", $product_id);
        echo json_encode(['success' => $ok]);
        exit;
    }

    echo json_encode(['success'=>false,'message'=>'Unknown action']);
    exit;
}

http_response_code(405);
echo json_encode(['success'=>false,'message'=>'Method not allowed']);
