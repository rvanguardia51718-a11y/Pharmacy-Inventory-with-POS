<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/notifications.php';

// Get current user role
$user_role = $_SESSION['role'] ?? '';
$user_name = $_SESSION['full_name'] ?? 'Staff';

// Get filter parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? intval($_GET['category']) : 0;
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Build main products query with filters
$query = "
    SELECT p.*, 
           c.name as category_name,
           COALESCE(SUM(CASE WHEN sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH) THEN sb.quantity_base ELSE 0 END), 0) as total_stock,
           MIN(sb.expiration_date) as earliest_expiry,
           COUNT(DISTINCT sb.id) as batch_count
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN stock_batches sb ON p.id = sb.product_id
    WHERE 1=1
";

$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND (p.brand_name LIKE ? OR p.generic_name LIKE ? OR p.barcode LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

if (!empty($category_filter)) {
    $query .= " AND p.category_id = ?";
    $params[] = $category_filter;
    $types .= "i";
}

$query .= " GROUP BY p.id";

// Apply status filter after grouping
if (!empty($status_filter)) {
    if ($status_filter === 'low_stock') {
        $query .= " HAVING total_stock < p.low_stock_threshold AND total_stock > 0";
    } elseif ($status_filter === 'out_of_stock') {
        $query .= " HAVING total_stock = 0";
    } elseif ($status_filter === 'in_stock') {
        $query .= " HAVING total_stock >= p.low_stock_threshold";
    }
}

$query .= " ORDER BY p.brand_name ASC";

// Execute main query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products_result = $stmt->get_result();

$products = [];
$total_stock_value = 0;
while ($row = $products_result->fetch_assoc()) {
    $products[] = $row;
    $total_stock_value += $row["total_stock"] * $row["cost"];
}
$stmt->close();

// Get categories for filter
$categories_result = $conn->query("
    SELECT c.id, c.name, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.name
");
$categories = [];
while ($row = $categories_result->fetch_assoc()) {
    $categories[] = $row;
}

// Statistics
$total_products = count($products);
$total_stock = array_sum(array_column($products, 'total_stock'));
$low_stock_count = count(array_filter($products, function($p) { 
    return $p['total_stock'] > 0 && $p['total_stock'] <= $p['low_stock_threshold']; 
}));
$out_of_stock_count = count(array_filter($products, function($p) { 
    return $p['total_stock'] == 0; 
}));
$expiring_count_stat = $conn->query("
    SELECT COUNT(*) FROM stock_batches
    WHERE expiration_date > CURDATE()
      AND expiration_date < DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
      AND quantity_base > 0
")->fetch_row()[0];
$expired_count_stat = $conn->query("
    SELECT COUNT(*) FROM stock_batches
    WHERE expiration_date <= CURDATE() AND quantity_base > 0
")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Viewer | CAD Crest Pharmaceutical</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Page-specific styles only */
:root {
    --primary-green: #004d40;
    --primary-dark: #00332c;
    --primary-light: #e8f5e9;
    --accent-gold: #b8860b;
    --bg-soft: #f0f4f8;
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
    --transition: all 0.2s ease;
    --danger: #dc2626;
    --warning: #f59e0b;
    --success: #10b981;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f293b;
}

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f0f7f4 100%);
            min-height: 100vh;
        }

        /* Header */
        .inventory-header {
            background: linear-gradient(135deg, var(--primary-green) 0%, #00695c 100%);
            padding: 2rem 2.5rem;
            border-radius: 32px;
            margin-bottom: 2rem;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 40px -10px rgba(0, 77, 64, 0.3);
        }

        .inventory-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .header-content {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1.5rem;
        }

        .header-text h1 {
            font-size: 2rem;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-text h1 i {
            background: rgba(255,255,255,0.2);
            padding: 12px;
            border-radius: 20px;
            font-size: 1.8rem;
            backdrop-filter: blur(10px);
        }

        .header-text p {
            font-size: 1rem;
            opacity: 0.9;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .read-only-badge {
            background: rgba(255,255,255,0.15);
            padding: 0.75rem 1.5rem;
            border-radius: 40px;
            font-weight: 600;
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
        }

        .read-only-badge i {
            color: var(--accent-gold);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.2rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 1.2rem;
            box-shadow: var(--card-shadow);
            transition: var(--transition);
            border: 1px solid rgba(0, 77, 64, 0.05);
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: var(--hover-shadow);
        }

        .stat-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            margin-bottom: 0.8rem;
            background: var(--primary-light);
            color: var(--primary-green);
        }

        .stat-label {
            color: #64748b;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.3rem;
        }

        .stat-value {
            font-size: 1.4rem;
            font-weight: 800;
            color: #1e293b;
            line-height: 1.2;
        }

        /* Filter Bar */
        .filter-bar {
            background: white;
            border-radius: 20px;
            padding: 1.2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .search-box {
            flex: 2;
            min-width: 250px;
        }

        .search-box label {
            display: block;
            margin-bottom: 0.4rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .search-input-wrapper {
            position: relative;
        }

        .search-input-wrapper i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 0.9rem;
        }

        .search-box input {
            width: 100%;
            padding: 0.7rem 1rem 0.7rem 2.2rem;
            border: 2px solid #f1f5f9;
            border-radius: 14px;
            font-size: 0.9rem;
            transition: var(--transition);
        }

        .search-box input:focus {
            outline: none;
            border-color: var(--primary-green);
            background: white;
            box-shadow: 0 0 0 3px rgba(0, 77, 64, 0.1);
        }

        .filter-group {
            flex: 1;
            min-width: 180px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 0.4rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .filter-group select {
            width: 100%;
            padding: 0.7rem 1rem;
            border: 2px solid #f1f5f9;
            border-radius: 14px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: var(--transition);
        }

        .filter-group select:focus {
            outline: none;
            border-color: var(--primary-green);
        }

        /* Filter Summary */
        .filter-summary {
            background: white;
            padding: 0.8rem 1.2rem;
            border-radius: 40px;
            margin-bottom: 1.5rem;
            display: inline-flex;
            align-items: center;
            gap: 1rem;
            box-shadow: var(--card-shadow);
        }

        .filter-summary span {
            color: #475569;
            font-size: 0.9rem;
        }

        .filter-summary strong {
            color: var(--primary-green);
        }

        .result-count {
            background: var(--primary-light);
            color: var(--primary-green);
            padding: 0.2rem 0.8rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        /* Tabs */
        .tabs-container {
            background: white;
            border-radius: 24px;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }

        .tabs-header {
            background: #f8fafc;
            display: flex;
            border-bottom: 1px solid #edf2f7;
            overflow-x: auto;
        }

        .tab-btn {
            padding: 1rem 2rem;
            border: none;
            background: none;
            font-weight: 600;
            color: #64748b;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.95rem;
            white-space: nowrap;
        }

        .tab-btn i {
            font-size: 1.1rem;
        }

        .tab-btn.active {
            color: var(--primary-green);
            background: white;
            border-bottom: 3px solid var(--primary-green);
        }

        .tab-content {
            padding: 1.5rem;
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Product Table - Responsive */
        .table-wrapper {
            overflow-x: auto;
            border-radius: 16px;
            border: 1px solid #edf2f7;
        }

        .product-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .product-table th {
            text-align: left;
            padding: 1rem;
            background: #f8fafc;
            color: #475569;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
        }

        .product-table td {
            padding: 1rem;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            font-size: 0.9rem;
        }

        .product-table tbody tr:hover {
            background: #f8fafc;
        }

        .product-info {
            display: flex;
            flex-direction: column;
        }

        .product-brand {
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 2px;
        }

        .product-generic {
            font-size: 0.75rem;
            color: #94a3b8;
            font-style: italic;
        }

        .badge {
            padding: 0.3rem 0.8rem;
            border-radius: 40px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }

        .badge-success {
            background: #dcfce7;
            color: #15803d;
        }

        .badge-warning {
            background: #ffedd5;
            color: #9a3412;
        }

        .badge-danger {
            background: #fee2e2;
            color: #b91c1c;
        }

        .badge-info {
            background: #e0f2fe;
            color: #0369a1;
        }

        .stock-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 6px;
        }

        .stock-high { background: #15803d; }
        .stock-low { background: #9a3412; }
        .stock-none { background: #b91c1c; }

        .price-value {
            font-weight: 700;
            color: var(--primary-green);
        }

        .barcode {
            font-family: 'Courier New', monospace;
            background: #f1f5f9;
            padding: 0.2rem 0.5rem;
            border-radius: 6px;
            font-size: 0.8rem;
        }

        /* Expiry Table - Responsive */
        .expiry-table-wrapper {
            overflow-x: auto;
            border-radius: 16px;
            border: 1px solid #edf2f7;
        }

        .expiry-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .expiry-table th {
            text-align: left;
            padding: 1rem;
            background: #f8fafc;
            color: #475569;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 2px solid #e2e8f0;
        }

        .expiry-table td {
            padding: 1rem;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
            font-size: 0.9rem;
        }

        .expiry-table tbody tr:hover {
            background: #f8fafc;
        }

        .expiry-table tr.expired-row {
            background: #fef2f2;
        }

        .expiry-table tr.expired-row:hover {
            background: #fee2e2;
        }

        .expiry-table tr.warning-row {
            background: #fffbeb;
        }

        .expiry-table tr.warning-row:hover {
            background: #fef3c7;
        }

        .days-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }

        .days-urgent {
            background: #fee2e2;
            color: #b91c1c;
        }

        .days-warning {
            background: #ffedd5;
            color: #9a3412;
        }

        .days-ok {
            background: #dcfce7;
            color: #15803d;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: #94a3b8;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--primary-green);
            opacity: 0.3;
        }

        .empty-state h3 {
            color: #334155;
            margin-bottom: 0.5rem;
        }

        /* Responsive Breakpoints */
        @media (max-width: 992px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .filter-bar {
                flex-direction: column;
            }
            
            .search-box,
            .filter-group {
                width: 100%;
            }
            
            .tabs-header {
                overflow-x: auto;
            }
            
            .tab-btn {
                padding: 0.8rem 1.2rem;
                font-size: 0.85rem;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }
            
            .stat-card {
                padding: 1rem;
            }
            
            .stat-value {
                font-size: 1.2rem;
            }
        }

        @media (max-width: 576px) {
            .inventory-header {
                padding: 1.5rem;
            }
            
            .header-text h1 {
                font-size: 1.6rem;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-summary {
                flex-wrap: wrap;
            }
            
            .tab-content {
                padding: 1rem;
            }
        }

        /* Stats Cards - Matching User Management Style */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.2rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 24px;
    padding: 1.5rem;
    box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    gap: 1.2rem;
    transition: all 0.2s ease;
    border: 1px solid rgba(0,0,0,0.02);
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #004d40, #b8860b);
    opacity: 0;
    transition: opacity 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 20px 35px -10px rgba(0, 77, 64, 0.2);
}

.stat-card:hover::before {
    opacity: 1;
}

.stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.6rem;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.stat-card:hover .stat-icon {
    transform: scale(1.05) rotate(3deg);
}

.stat-details {
    flex: 1;
}

.stat-details h3 {
    font-size: 0.8rem;
    color: #64748b;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.25rem;
}

.stat-details .value {
    font-size: 1.8rem;
    font-weight: 800;
    color: #1e293b;
    line-height: 1.2;
    margin-bottom: 0.2rem;
}

.stat-badge {
    display: inline-block;
    font-size: 0.7rem;
    padding: 0.2rem 0.8rem;
    background: #f1f5f9;
    border-radius: 40px;
    color: #475569;
    font-weight: 600;
}

.stat-badge.warning {
    background: #fff3e0;
    color: #b8860b;
}

.stat-badge.danger {
    background: #fee2e2;
    color: #b91c1c;
}

.stat-badge.success {
    background: #e8f5e9;
    color: #004d40;
}

/* Responsive */
@media (max-width: 992px) {
    .stats-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    
    .stat-card {
        padding: 1.2rem;
    }
    
    .stat-details .value {
        font-size: 1.5rem;
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
}
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <div class="main-content">
        <!-- Header -->
        <div class="inventory-header">
            <div class="header-content">
                <div class="header-text">
                    <h1>
                        <i class="fa-solid fa-warehouse"></i>
                        Inventory Viewer
                    </h1>
                    <p>
                        <i class="fa-regular fa-eye"></i>
                        View-only access • <?php echo date('l, F j, Y'); ?>
                    </p>
                </div>
                <div class="read-only-badge">
                    <i class="fa-regular fa-shield"></i>
                    Read Only Mode
                </div>
            </div>
        </div>

<!-- Statistics Cards - Matching User Management Style -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-pills"></i>
        </div>
        <div class="stat-details">
            <h3>Total Products</h3>
            <div class="value"><?php echo number_format($total_products); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-exclamation"></i>
        </div>
        <div class="stat-details">
            <h3>Low Stock</h3>
            <div class="value"><?php echo $low_stock_count; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-circle-exclamation"></i>
        </div>
        <div class="stat-details">
            <h3>Out of Stock</h3>
            <div class="value"><?php echo $out_of_stock_count; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-clock"></i>
        </div>
        <div class="stat-details">
            <h3>Near Expiry</h3>
            <div class="value"><?php echo $expiring_count_stat; ?></div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-calendar-xmark"></i>
        </div>
        <div class="stat-details">
            <h3>Expired</h3>
            <div class="value"><?php echo $expired_count_stat; ?></div>
        </div>
    </div>
</div>
        <!-- Filter Bar -->
        <div class="filter-bar">
            <div class="search-box">
                <label><i class="fa-solid fa-search"></i> Search Products</label>
                <div class="search-input-wrapper">
                    <i class="fa-regular fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search by name, generic, or barcode..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>

            <div class="filter-group">
                <label><i class="fa-solid fa-tag"></i> Category</label>
                <select id="categoryFilter">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php echo $category_filter == $cat['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['name']); ?> (<?php echo $cat['product_count']; ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Filter Summary -->
        <?php if (!empty($search) || !empty($category_filter)): ?>
        <div class="filter-summary">
            <i class="fa-regular fa-filter"></i>
            <span>Active filters:</span>
            <?php if (!empty($search)): ?>
                <strong>"<?php echo htmlspecialchars($search); ?>"</strong>
            <?php endif; ?>
            <?php if (!empty($category_filter)): ?>
                <?php 
                $cat_name = '';
                foreach ($categories as $cat) {
                    if ($cat['id'] == $category_filter) {
                        $cat_name = $cat['name'];
                        break;
                    }
                }
                ?>
                <strong><?php echo htmlspecialchars($cat_name); ?></strong>
            <?php endif; ?>
            <span class="result-count"><?php echo count($products); ?> products found</span>
        </div>
        <?php endif; ?>

        <!-- Tabs Container -->
        <div class="tabs-container">
            <div class="tabs-header">
                <button class="tab-btn active" onclick="openTab(event, 'allProducts')">
                    <i class="fa-regular fa-table"></i> All Products
                </button>
                <button class="tab-btn" onclick="openTab(event, 'expiryTracking')">
                    <i class="fa-regular fa-clock"></i> Expiry Tracking
                </button>
            </div>

            <!-- All Products Tab -->
            <div id="allProducts" class="tab-content active">
                <?php if (empty($products)): ?>
                    <div class="empty-state">
                        <i class="fa-regular fa-box-open"></i>
                        <h3>No Products Found</h3>
                        <p>Try adjusting your search or filter criteria</p>
                    </div>
                <?php else: ?>
                    <div class="table-wrapper">
                        <table class="product-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Barcode</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product): 
                                    $stock_class = 'stock-high';
                                    $badge_class = 'badge-success';
                                    $status_text = 'In Stock';
                                    
                                    if ($product['total_stock'] == 0) {
                                        $stock_class = 'stock-none';
                                        $badge_class = 'badge-danger';
                                        $status_text = 'Out of Stock';
                                    } elseif ($product['total_stock'] < 10) {
                                        $stock_class = 'stock-low';
                                        $badge_class = 'badge-warning';
                                        $status_text = 'Low Stock';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <div class="product-info">
                                            <span class="product-brand"><?php echo htmlspecialchars($product['brand_name']); ?></span>
                                            <span class="product-generic"><?php echo htmlspecialchars($product['generic_name']); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if (!empty($product['barcode'])): ?>
                                            <span class="barcode"><?php echo htmlspecialchars($product['barcode']); ?></span>
                                        <?php else: ?>
                                            <span style="color: #94a3b8;">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
                                    <td><span class="price-value">₱<?php echo number_format($product['price'], 2); ?></span></td>
                                    <td>
                                        <span class="stock-indicator <?php echo $stock_class; ?>"></span>
                                        <?php echo $product['total_stock']; ?> units
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $badge_class; ?>">
                                            <?php echo $status_text; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Expiry Tracking Tab -->
            <div id="expiryTracking" class="tab-content">
                <?php
                $all_expiry_batches = [];
                $eq = $conn->query("
                    SELECT sb.*, p.brand_name, p.generic_name, c.name as category_name,
                           DATEDIFF(sb.expiration_date, CURDATE()) as days_left
                    FROM stock_batches sb
                    JOIN products p ON sb.product_id = p.id
                    LEFT JOIN categories c ON p.category_id = c.id
                    WHERE sb.quantity_base > 0
                      AND sb.expiration_date < DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
                    ORDER BY
                        CASE WHEN sb.expiration_date <= CURDATE() THEN 1 ELSE 2 END,
                        sb.expiration_date ASC
                ");
                if ($eq) {
                    while ($row = $eq->fetch_assoc()) {
                        $all_expiry_batches[] = $row;
                    }
                }
                ?>
                <?php if (empty($all_expiry_batches)): ?>
                    <div class="empty-state">
                        <i class="fa-regular fa-calendar-check"></i>
                        <h3>No Expiry Alerts</h3>
                        <p>No products are expired or expiring within the next 30 days</p>
                    </div>
                <?php else: ?>
                    <div class="expiry-table-wrapper">
                        <table class="expiry-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Category</th>
                                    <th>Batch #</th>
                                    <th>Expiry Date</th>
                                    <th>Days Left</th>
                                    <th>Stock</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_expiry_batches as $batch):
                                    $days = (int)$batch['days_left'];
                                    if ($days <= 0) {
                                        $row_class = 'expired-row';
                                        $badge_class = 'badge-danger';
                                        $status_text = 'Expired';
                                        $days_display = '<span class="days-badge days-urgent">Expired ' . abs($days) . ' days ago</span>';
                                    } else {
                                        $row_class = $days <= 7 ? 'expired-row' : 'warning-row';
                                        $badge_class = $days <= 7 ? 'badge-danger' : 'badge-warning';
                                        $status_text = 'Near Expiry';
                                        $days_display = '<span class="days-badge ' . ($days <= 7 ? 'days-urgent' : 'days-warning') . '">' . $days . ' days</span>';
                                    }
                                ?>
                                <tr class="<?php echo $row_class; ?>">
                                    <td>
                                        <div class="product-info">
                                            <span class="product-brand"><?php echo htmlspecialchars($batch['brand_name']); ?></span>
                                            <span class="product-generic"><?php echo htmlspecialchars($batch['generic_name']); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($batch['category_name'] ?? 'Uncategorized'); ?></td>
                                    <td>
                                        <?php if (!empty($batch['batch_number'])): ?>
                                            <span class="barcode"><?php echo htmlspecialchars($batch['batch_number']); ?></span>
                                        <?php else: ?>
                                            <span style="color: #94a3b8;">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($batch['expiration_date'])); ?></td>
                                    <td><?php echo $days_display; ?></td>
                                    <td><?php echo $batch['quantity_base']; ?> units</td>
                                    <td>
                                        <span class="badge <?php echo $badge_class; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Tab switching
        function openTab(evt, tabName) {
            const tabContents = document.getElementsByClassName("tab-content");
            for (let i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            const tabBtns = document.getElementsByClassName("tab-btn");
            for (let i = 0; i < tabBtns.length; i++) {
                tabBtns[i].classList.remove("active");
            }
            
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        // Filter functions
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        
        let filterTimeout;
        
        function applyFilters() {
            clearTimeout(filterTimeout);
            filterTimeout = setTimeout(() => {
                const url = new URL(window.location.href);
                
                if (searchInput.value) {
                    url.searchParams.set('search', searchInput.value);
                } else {
                    url.searchParams.delete('search');
                }
                
                if (categoryFilter.value) {
                    url.searchParams.set('category', categoryFilter.value);
                } else {
                    url.searchParams.delete('category');
                }
                
                url.searchParams.delete('status');
                
                window.location.href = url.toString();
            }, 500);
        }
        
        searchInput.addEventListener('input', applyFilters);
        categoryFilter.addEventListener('change', applyFilters);
    </script>

    <?php renderNotificationPanel($conn); ?>
</body>
</html>