<?php
/**
 * admin/inventory.php - Simplified inventory with modals matching images
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/notifications.php';
require_once __DIR__ . '/../includes/inventory_helper.php';

restrictToAdmin();
$user_id = (int)$_SESSION['user_id'];
$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $act = $_POST['action'];
    
// ── ADD PRODUCT ─────────────────────────────────────────
if ($act === 'add_product') {
    // Fix: Set empty barcode to NULL (prevents duplicate entry error)
    $barcode = trim($_POST['barcode'] ?? '');
    if (empty($barcode)) {
        $barcode = null;
    }
    
    $brand_name = trim($_POST['brand_name'] ?? '');
    $generic_name = trim($_POST['generic_name'] ?? '');
    $dosage_form = trim($_POST['dosage_form'] ?? '');
    $strength = trim($_POST['strength'] ?? '');
    $category_id = intval($_POST['category_id'] ?? 0);
    $base_unit = trim($_POST['base_unit'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $cost = floatval($_POST['cost'] ?? 0);
    $threshold = max(1, intval($_POST['low_stock_threshold'] ?? 10));
    
    // Unit data
    $unit_names = $_POST['unit_name'] ?? [];
    $unit_convs = $_POST['unit_conv'] ?? [];
    
    // Initial stock data
    $purchase_qty = intval($_POST['purchase_qty'] ?? 0);
    $conversion_factor = max(1, intval($_POST['conversion_factor'] ?? 1));
    $initial_qty = $purchase_qty * $conversion_factor;
    $expiry_date = $_POST['expiry_date'] ?? '';
    $date_received = $_POST['date_received'] ?? date('Y-m-d');
    $purchase_unit_name = trim($_POST['purchase_unit'] ?? '');
    
    // Validation
    if (empty($brand_name) || $category_id <= 0 || $price <= 0) {
        $error = "Please fill in all required fields (Product Name, Category, Selling Price).";
    } elseif (empty($base_unit)) {
        $error = "Please select a Base Unit.";
    } elseif (empty($dosage_form)) {
        $error = "Please select a Dosage Form.";
    } elseif ($purchase_qty > 0 && $cost <= 0) {
        $error = "Cost per purchase unit is required when entering initial stock.";
    } else {
        $conn->begin_transaction();
        try {
            // Insert product - with NULL barcode support
            $stmt = $conn->prepare("
                INSERT INTO products (
                    barcode, brand_name, generic_name, dosage_form, strength, 
                    category_id, base_unit, price, vat_type, cost, low_stock_threshold
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'vatable', ?, ?)
            ");
            
            $stmt->bind_param(
                "sssssisddi",
                $barcode, $brand_name, $generic_name, $dosage_form, $strength,
                $category_id, $base_unit, $price, $cost, $threshold
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Database error: " . $stmt->error);
            }
            
            $product_id = $conn->insert_id;
            $stmt->close();
            
            // Add base unit
            $stmt = $conn->prepare("
                INSERT INTO product_units (product_id, unit_name, conversion_to_base, sort_order)
                VALUES (?, ?, 1, 99)
            ");
            $stmt->bind_param("is", $product_id, $base_unit);
            $stmt->execute();
            $stmt->close();
            
            // Add purchase unit if different from base unit
            if (!empty($purchase_unit_name) && $purchase_unit_name !== $base_unit && $conversion_factor > 1) {
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO product_units
                    (product_id, unit_name, conversion_to_base, sort_order)
                    VALUES (?, ?, ?, 1)
                ");
                $stmt->bind_param("isi", $product_id, $purchase_unit_name, $conversion_factor);
                $stmt->execute();
                $stmt->close();
            }

            // Add additional units if any
            if (!empty($unit_names)) {
                foreach ($unit_names as $i => $unit_name) {
                    $unit_name = trim($unit_name);
                    if (empty($unit_name) || $unit_name === 'base') continue;
                    if ($unit_name === $purchase_unit_name) continue;
                    
                    $conv = max(1, intval($unit_convs[$i] ?? 1));
                    
                    $stmt = $conn->prepare("
                        INSERT IGNORE INTO product_units 
                        (product_id, unit_name, conversion_to_base, sort_order)
                        VALUES (?, ?, ?, 0)
                    ");
                    $stmt->bind_param("isi", $product_id, $unit_name, $conv);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            
            // Add initial stock if provided
            if ($initial_qty > 0 && !empty($expiry_date)) {
                $batch_number = date('Ymd') . '-' . str_pad($product_id, 4, '0', STR_PAD_LEFT) . '-' . rand(100, 999);
                
                $stmt = $conn->prepare("
                    INSERT INTO stock_batches 
                    (product_id, batch_number, quantity_base, expiration_date, received_unit, received_qty, date_added)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("isissis", 
                    $product_id, $batch_number, $initial_qty, $expiry_date, $base_unit, $purchase_qty, $date_received
                );
                $stmt->execute();
                $stmt->close();
            }
            
            $conn->commit();
            $message = "Product added successfully!";
            
            // Log activity
            $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Add Product', ?)");
            $desc = "Added product: $brand_name";
            $log->bind_param("is", $user_id, $desc);
            $log->execute();
            $log->close();
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
        }
    }
}
    
    // ── ADD STOCK (Restock with unit conversion) ────────────
    elseif ($act === 'add_stock') {
        $product_id    = intval($_POST['product_id']);
        $quantity      = intval($_POST['quantity']);
        $received_unit = trim($_POST['received_unit'] ?? '');
        $conv_factor   = max(1, intval($_POST['restock_conversion'] ?? 1));
        $expiry_date   = $_POST['expiry_date'] ?? '';
        $date_received = $_POST['date_received'] ?? date('Y-m-d');
        $notes         = trim($_POST['notes'] ?? '');
        
        if ($quantity <= 0) {
            $error = "Quantity must be greater than 0.";
        } elseif (empty($expiry_date)) {
            $error = "Expiry date is required.";
        } else {
            try {
                $stmt = $conn->prepare("SELECT brand_name, base_unit FROM products WHERE id = ?");
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $product = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                
                if (!$product) throw new Exception("Product not found.");
                
                $actual_base_unit = $product['base_unit'];
                $quantity_base    = $quantity;
                $actual_recv_unit = !empty($received_unit) ? $received_unit : $actual_base_unit;
                
                if (!empty($received_unit) && $received_unit !== $actual_base_unit) {
                    $cu = $conn->prepare("SELECT conversion_to_base FROM product_units WHERE product_id=? AND unit_name=? LIMIT 1");
                    $cu->bind_param("is", $product_id, $received_unit);
                    $cu->execute();
                    $cu_row = $cu->get_result()->fetch_assoc();
                    $cu->close();
                    
                    if ($cu_row) {
                        $quantity_base = $quantity * (int)$cu_row['conversion_to_base'];
                    } else {
                        $quantity_base = $quantity * $conv_factor;
                    }
                }
                
                $batch_number = generateBatchNumber($conn, $product_id);
                
                $stmt = $conn->prepare("
                    INSERT INTO stock_batches 
                    (product_id, batch_number, quantity_base, expiration_date, received_unit, received_qty, date_added)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("isissis", 
                    $product_id, $batch_number, $quantity_base, $expiry_date, $actual_recv_unit, $quantity, $date_received
                );
                $stmt->execute();
                $affected = $stmt->affected_rows;
                $stmt->close();
                
                if ($affected > 0) {
                    $message = "Stock added successfully! Batch #$batch_number (+$quantity_base {$actual_base_unit})";
                    $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Add Stock', ?)");
                    $desc = "Added $quantity $actual_recv_unit ($quantity_base {$actual_base_unit}) to {$product['brand_name']}";
                    $log->bind_param("is", $user_id, $desc);
                    $log->execute();
                    $log->close();
                } else {
                    $error = "Failed to add stock to database.";
                }
                
            } catch (Exception $e) {
                $error = "Error: " . $e->getMessage();
            }
        }
    }
    
    elseif ($act === 'edit_product') {
        $product_id = intval($_POST['product_id'] ?? 0);
        $brand_name = trim($_POST['brand_name'] ?? '');
        $generic_name = trim($_POST['generic_name'] ?? '');
        $dosage_form = trim($_POST['dosage_form'] ?? '');
        $strength = trim($_POST['strength'] ?? '');
        $category_id = intval($_POST['category_id'] ?? 0);
        $price = floatval($_POST['price'] ?? 0);
        $barcode = trim($_POST['barcode'] ?? '');
        $threshold = max(1, intval($_POST['low_stock_threshold'] ?? 10));
        
        if (empty($brand_name) || $category_id <= 0 || $price <= 0) {
            $error = "Please fill in all required fields correctly.";
        } else {
            $stmt = $conn->prepare("
                UPDATE products SET brand_name=?, generic_name=?, dosage_form=?, strength=?,
                category_id=?, price=?, barcode=?, low_stock_threshold=?
                WHERE id=?
            ");
            $stmt->bind_param("ssssissii", $brand_name, $generic_name, $dosage_form, $strength,
                $category_id, $price, $barcode, $threshold, $product_id);
            $stmt->execute();
            $stmt->close();
            $message = "Product updated successfully!";
            
            $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Edit Product', ?)");
            $desc = "Edited product: $brand_name";
            $log->bind_param("is", $user_id, $desc);
            $log->execute();
            $log->close();
        }
    }
    
    // ── DELETE PRODUCT ─────────────────────────────────────
    elseif ($act === 'delete_product') {
        $id = intval($_POST['id']);
        
        // Get product name for logging
        $stmt = $conn->prepare("SELECT brand_name FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$product) {
            $error = "Product not found.";
        } else {
            // Check if product has any sales records
            $check_sales = $conn->prepare("SELECT COUNT(*) as count FROM sale_items WHERE product_id = ?");
            $check_sales->bind_param("i", $id);
            $check_sales->execute();
            $sales_result = $check_sales->get_result();
            $sales_count = $sales_result->fetch_assoc()['count'];
            $check_sales->close();
            
            if ($sales_count > 0) {
                $error = "Cannot delete product because it has {$sales_count} sales record(s). This product has been sold in the past.";
            } else {
                // Start transaction
                $conn->begin_transaction();
                
                try {
                    // 1. Delete from stock_batches first
                    $del_batches = $conn->prepare("DELETE FROM stock_batches WHERE product_id = ?");
                    $del_batches->bind_param("i", $id);
                    $del_batches->execute();
                    $batches_deleted = $del_batches->affected_rows;
                    $del_batches->close();
                    
                    // 2. Delete from product_units
                    $del_units = $conn->prepare("DELETE FROM product_units WHERE product_id = ?");
                    $del_units->bind_param("i", $id);
                    $del_units->execute();
                    $units_deleted = $del_units->affected_rows;
                    $del_units->close();
                    
                    // 3. Delete notifications
                    $del_notifications = $conn->prepare("DELETE FROM notifications WHERE reference_id = ?");
                    $del_notifications->bind_param("i", $id);
                    $del_notifications->execute();
                    $del_notifications->close();
                    
                    // 4. Finally delete the product
                    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                    $deleted = $stmt->affected_rows;
                    $stmt->close();
                    
                    if ($deleted > 0) {
                        $conn->commit();
                        $message = "Product deleted successfully! Removed {$batches_deleted} batches and {$units_deleted} unit definitions.";
                        
                        // Log activity
                        $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Delete Product', ?)");
                        $desc = "Deleted product: {$product['brand_name']} (ID: {$id})";
                        $log->bind_param("is", $user_id, $desc);
                        $log->execute();
                        $log->close();
                    } else {
                        $conn->rollback();
                        $error = "Failed to delete product from database. No rows affected.";
                    }
                    
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = "Error deleting product: " . $e->getMessage();
                }
            }
        }
    }
    
    // ── DELETE BATCH (expired) ──────────────────────────────
    elseif ($act === 'delete_batch') {
        $batch_id = intval($_POST['batch_id']);
        $force    = isset($_POST['force_delete']) && $_POST['force_delete'] === '1';

        $stmt = $conn->prepare("SELECT sb.id, sb.expiration_date, sb.batch_number, p.brand_name FROM stock_batches sb JOIN products p ON p.id=sb.product_id WHERE sb.id=?");
        $stmt->bind_param("i", $batch_id);
        $stmt->execute();
        $batch = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$batch) {
            $error = "Batch not found.";
        } else {
            // Check if this batch is referenced in sale_items (FK constraint)
            $chk = $conn->prepare("SELECT COUNT(*) as cnt FROM sale_items WHERE batch_id=?");
            $chk->bind_param("i", $batch_id);
            $chk->execute();
            $used_count = (int)$chk->get_result()->fetch_assoc()['cnt'];
            $chk->close();

            if ($used_count > 0 && !$force) {
                $error = "BATCH_IN_USE:{$used_count}:{$batch['batch_number']}:{$batch_id}";
            } else {
                $conn->begin_transaction();
                try {
                    if ($used_count > 0) {
                        // Reassign sale_items to a placeholder batch (id=0 not possible; use null via ALTER not needed — update to another batch of same product or just remove the FK reference via UPDATE)
                        // Since batch_id is NOT NULL FK, we update sale_items to reference the first remaining batch of the same product, or 0 isn't valid.
                        // Best safe approach: delete the batch and let MySQL cascade if configured, else update sale_items batch_id to the oldest remaining batch of the same product
                        $fallback = $conn->prepare("SELECT id FROM stock_batches WHERE product_id=(SELECT product_id FROM stock_batches WHERE id=?) AND id != ? ORDER BY id ASC LIMIT 1");
                        $fallback->bind_param("ii", $batch_id, $batch_id);
                        $fallback->execute();
                        $fb_row = $fallback->get_result()->fetch_assoc();
                        $fallback->close();

                        if ($fb_row) {
                            $upd = $conn->prepare("UPDATE sale_items SET batch_id=? WHERE batch_id=?");
                            $upd->bind_param("ii", $fb_row['id'], $batch_id);
                            $upd->execute();
                            $upd->close();
                        } else {
                            // No other batch exists — create a ghost/archive batch first
                            $ghost = $conn->prepare("INSERT INTO stock_batches (product_id, batch_number, quantity_base, expiration_date, received_unit, received_qty, date_added) SELECT product_id, CONCAT('ARCHIVED-',batch_number), 0, expiration_date, received_unit, received_qty, date_added FROM stock_batches WHERE id=?");
                            $ghost->bind_param("i", $batch_id);
                            $ghost->execute();
                            $ghost_id = $conn->insert_id;
                            $ghost->close();
                            $upd = $conn->prepare("UPDATE sale_items SET batch_id=? WHERE batch_id=?");
                            $upd->bind_param("ii", $ghost_id, $batch_id);
                            $upd->execute();
                            $upd->close();
                        }
                    }

                    $del = $conn->prepare("DELETE FROM stock_batches WHERE id=?");
                    $del->bind_param("i", $batch_id);
                    $del->execute();
                    $deleted = $del->affected_rows;
                    $del->close();

                    if ($deleted > 0) {
                        $conn->commit();
                        $message = "Batch deleted successfully." . ($used_count > 0 ? " ({$used_count} sale record(s) reassigned to archive.)" : "");
                        $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Delete Batch', ?)");
                        $desc = "Deleted batch #{$batch_id} ({$batch['batch_number']}) of {$batch['brand_name']}" . ($used_count > 0 ? " - force deleted, {$used_count} sale items reassigned" : "");
                        $log->bind_param("is", $user_id, $desc);
                        $log->execute();
                        $log->close();
                    } else {
                        $conn->rollback();
                        $error = "Failed to delete batch.";
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = "Error: " . $e->getMessage();
                }
            }
        }
    }
    
    elseif ($act === 'add_category') {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        if (empty($name)) {
            $error = "Category name required.";
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
            $stmt->bind_param("ss", $name, $desc);
            $stmt->execute();
            $stmt->close();
            $message = "Category added successfully!";
        }
    }
    
    // ── DELETE CATEGORY ─────────────────────────────────────
    elseif ($act === 'delete_category') {
        $id = intval($_POST['id']);
        
        // Check if category is used by any products
        $check = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        $result = $check->get_result();
        $product_count = $result->fetch_assoc()['count'];
        $check->close();
        
        if ($product_count > 0) {
            $error = "Cannot delete category that has {$product_count} product(s).";
        } else {
            $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                $message = "Category deleted successfully!";
                
                // Log activity
                $log = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Delete Category', ?)");
                $desc = "Deleted category ID: {$id}";
                $log->bind_param("is", $user_id, $desc);
                $log->execute();
                $log->close();
            } else {
                $error = "Failed to delete category.";
            }
            $stmt->close();
        }
    }
}

// Get filter parameters
$search = $_GET['search'] ?? '';
$category_filter = intval($_GET['category'] ?? 0);

// Build query for products - SIMPLE table
$query = "
    SELECT p.*, c.name as category_name,
           COALESCE(SUM(sb.quantity_base), 0) as total_stock
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN stock_batches sb ON p.id = sb.product_id AND sb.expiration_date >= CURDATE()
    WHERE 1=1
";

$params = [];
$types = "";

if (!empty($search)) {
    $query .= " AND (p.brand_name LIKE ? OR p.generic_name LIKE ? OR p.barcode LIKE ?)";
    $search_param = "%$search%";
    $params = [$search_param, $search_param, $search_param];
    $types = "sss";
}

if ($category_filter > 0) {
    $query .= " AND p.category_id = ?";
    $params[] = $category_filter;
    $types .= "i";
}

$query .= " GROUP BY p.id ORDER BY p.brand_name ASC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get categories for filter
$categories = $conn->query("
    SELECT c.id, c.name, COUNT(p.id) as product_count
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.name
")->fetch_all(MYSQLI_ASSOC);

// Get all categories for categories tab
$all_categories = $conn->query("SELECT * FROM categories ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Get batches for expiry tab
$batches = $conn->query("
    SELECT sb.*, p.brand_name, p.generic_name, c.name as category_name,
           DATEDIFF(sb.expiration_date, CURDATE()) as days_left
    FROM stock_batches sb
    JOIN products p ON p.id = sb.product_id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE sb.quantity_base > 0
    ORDER BY sb.expiration_date ASC
")->fetch_all(MYSQLI_ASSOC);

// Stats
$total_products = count($products);

$low_stock_count = $conn->query("
    SELECT COUNT(*) FROM products p
    WHERE (
        SELECT COALESCE(SUM(sb.quantity_base), 0)
        FROM stock_batches sb
        WHERE sb.product_id = p.id
          AND sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
    ) > 0
    AND (
        SELECT COALESCE(SUM(sb.quantity_base), 0)
        FROM stock_batches sb
        WHERE sb.product_id = p.id
          AND sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
    ) <= p.low_stock_threshold
")->fetch_row()[0];

$out_of_stock_count = $conn->query("
    SELECT COUNT(DISTINCT p.id)
    FROM products p
    WHERE NOT EXISTS (
        SELECT 1 FROM stock_batches sb
        WHERE sb.product_id = p.id
          AND sb.quantity_base > 0
          AND sb.expiration_date >= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
    )
    AND EXISTS (
        SELECT 1 FROM stock_batches sb WHERE sb.product_id = p.id
    )
")->fetch_row()[0];

$near_expiry_count = $conn->query("
    SELECT COUNT(*) FROM stock_batches
    WHERE expiration_date > CURDATE()
      AND expiration_date < DATE_ADD(CURDATE(), INTERVAL 1 MONTH)
      AND quantity_base > 0
")->fetch_row()[0];

$expired_count = $conn->query("
    SELECT COUNT(*) FROM stock_batches
    WHERE expiration_date <= CURDATE()
      AND quantity_base > 0
")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management | CAD Crest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Page-specific styles only */
:root {
    --primary-green: #004d40;
    --primary-dark: #00332c;
    --primary-light: #e8f5e9;
    --accent-gold: #b8860b;
    --bg-soft: #f0f4f8;
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
    --transition: all 0.2s ease;
    --danger: #dc2626;
    --warning: #f59e0b;
    --success: #10b981;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f293b;
}
        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .page-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary-green);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .page-header h1 i {
            background: var(--primary-light);
            padding: 0.75rem;
            border-radius: 1rem;
            color: var(--primary-green);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s;
        }

.btn-primary {
    background: linear-gradient(135deg, var(--primary-green), #00695c);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #00695c, var(--primary-dark));
    transform: translateY(-2px);
    box-shadow: 0 10px 25px -5px rgba(0, 77, 64, 0.3);
}


        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-outline {
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-700);
        }

        .btn-outline:hover {
            background: var(--gray-50);
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 1rem;
            border: 1px solid var(--gray-100);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            background: var(--primary-light);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.5rem;
        }

        .stat-info h3 {
            font-size: 0.8rem;
            color: var(--gray-500);
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 0.25rem;
        }

        .stat-info .value {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--gray-800);
            line-height: 1.2;
        }

        /* Filter Bar */
        .filter-bar {
            background: white;
            padding: 1.25rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            display: flex;
            gap: 1rem;
            align-items: flex-end;
            border: 1px solid var(--gray-100);
        }

        .filter-group {
            flex: 1;
        }

        .filter-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            margin-bottom: 0.5rem;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-200);
            border-radius: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: var(--primary-green);
            box-shadow: 0 0 0 3px rgba(0, 77, 64, 0.1);
        }

        /* Tabs */
        .tabs-container {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border: 1px solid var(--gray-100);
        }

        .tabs-header {
            background: var(--gray-50);
            display: flex;
            border-bottom: 1px solid var(--gray-200);
            overflow-x: auto;
        }

        .tab-btn {
            padding: 1rem 2rem;
            border: none;
            background: none;
            font-weight: 600;
            color: var(--gray-600);
            cursor: pointer;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .tab-btn i {
            font-size: 1rem;
        }

        .tab-btn.active {
            color: var(--primary-green);
            background: white;
            border-bottom: 3px solid var(--primary-green);
        }

        .tab-content {
            padding: 1.5rem;
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Table Container - Responsive */
        .table-container {
            overflow-x: auto;
            border-radius: 0.75rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        th {
            text-align: left;
            padding: 1rem 1.5rem;
            background: var(--gray-50);
            color: var(--gray-600);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 1px solid var(--gray-200);
        }

        td {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--gray-100);
            color: var(--gray-700);
            font-size: 0.9rem;
        }

        tbody tr:hover {
            background: var(--gray-50);
        }

        .product-name-link {
            color: var(--primary-green);
            font-weight: 700;
            text-decoration: none;
            border-bottom: 1px dashed var(--primary-green);
            cursor: pointer;
        }

        .product-name-link:hover {
            color: var(--primary-dark);
        }

        .product-generic {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 0.25rem;
        }

        .category-badge {
            background: var(--gray-100);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--gray-700);
            display: inline-block;
        }

        .price-value {
            font-weight: 700;
            color: var(--primary-green);
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }

        .status-good {
            background: #dcfce7;
            color: #15803d;
        }

        .status-low {
            background: #ffedd5;
            color: #9a3412;
        }

        .status-out {
            background: #fee2e2;
            color: #b91c1c;
        }

        .action-cell {
            display: flex;
            gap: 0.5rem;
        }

        .action-btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            transition: all 0.2s;
        }

        .btn-stock {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .btn-stock:hover {
            background: #c8e6c9;
        }

        .btn-delete {
            background: #ffebee;
            color: #c62828;
        }

        .btn-delete:hover {
            background: #ffcdd2;
        }

        /* Expiry Table */
        .expiry-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        .expiry-table th {
            text-align: left;
            padding: 1rem;
            background: var(--gray-50);
            color: var(--gray-600);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            border-bottom: 1px solid var(--gray-200);
        }

        .expiry-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--gray-100);
        }

        .expired-row {
            background: #ffebee;
        }

        .warning-row {
            background: #fff3e0;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(4px);
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            width: 95%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            border-radius: 1.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

.modal-header {
    padding: 1.5rem 2rem;
    border-bottom: 1px solid var(--gray-200);
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: linear-gradient(135deg, var(--primary-green), #00695c);
    color: white;
    border-radius: 1.5rem 1.5rem 0 0;
}

        .modal-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .modal-close {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            font-size: 1.2rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 2rem;
        }

        /* Form styles */
        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--gray-600);
            margin-bottom: 0.5rem;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--gray-200);
            border-radius: 0.75rem;
            font-size: 0.95rem;
            transition: all 0.2s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-green);
            box-shadow: 0 0 0 3px rgba(0, 77, 64, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        /* Stock section */
        .stock-section {
            margin: 2rem 0;
            border: 1px solid var(--gray-200);
            border-radius: 1rem;
            overflow: hidden;
        }

        .stock-header {
            background: var(--gray-50);
            padding: 1rem;
            font-weight: 700;
            font-size: 0.9rem;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .stock-row {
            padding: 1rem;
            border-bottom: 1px solid var(--gray-200);
        }

        /* Current stock info */
        .current-stock-info {
            background: var(--gray-50);
            padding: 1rem;
            border-radius: 0.75rem;
            margin-bottom: 1.5rem;
            border: 1px solid var(--gray-200);
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .info-row:last-child {
            margin-bottom: 0;
        }

        .info-label {
            color: var(--gray-600);
        }

        .info-value {
            font-weight: 700;
            color: var(--gray-800);
        }

        /* Batch preview */
        .batch-preview {
            background: var(--gray-50);
            padding: 0.75rem 1rem;
            border-radius: 0.75rem;
            font-size: 0.85rem;
            color: var(--gray-600);
            border: 1px solid var(--gray-200);
            margin-top: 0.5rem;
        }

        .batch-preview strong {
            color: var(--primary-green);
            font-family: monospace;
        }

        /* Alert messages */
        .alert {
            padding: 1rem;
            border-radius: 0.75rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #a5d6a7;
        }

        .alert-error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 4rem;
            color: var(--gray-400);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
        }

        /* Expiry filter buttons */
        .expiry-filter-btn {
            background: #fff;
            border: 1px solid #d1d5db;
            padding: .4rem .9rem;
            border-radius: 20px;
            font-size: .78rem;
            font-weight: 600;
            cursor: pointer;
            transition: .2s;
        }
        .expiry-filter-btn.active {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: #fff;
        }

        /* Confirm Dialog */
        #confirmDialog {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        /* Responsive Breakpoints */
        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        @media (max-width: 992px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }
            
            .filter-bar {
                flex-direction: column;
            }
            
            .filter-group {
                width: 100%;
            }
            
            .tabs-header {
                flex-wrap: nowrap;
            }
            
            .tab-btn {
                padding: 0.8rem 1.2rem;
                font-size: 0.8rem;
            }
            
            .modal-content {
                width: 95%;
                margin: 10px;
            }
            
            .modal-body {
                padding: 1rem;
            }
            
            .action-cell {
                flex-direction: column;
            }
        }

        @media (max-width: 576px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .stat-card {
                padding: 1rem;
            }
            
            .stat-info .value {
                font-size: 1.4rem;
            }
            
            .page-header h1 {
                font-size: 1.5rem;
            }
            
            .modal-header {
                padding: 1rem;
            }
            
            .modal-header h2 {
                font-size: 1.2rem;
            }
            
            .form-row {
                gap: 0.5rem;
            }
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        @keyframes modalPop {
            from { transform: scale(.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        /* Stats Cards - Matching User Management Style */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: white;
    border-radius: 24px;
    padding: 1.5rem;
    box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    gap: 1.2rem;
    transition: all 0.2s ease;
    border: 1px solid rgba(0,0,0,0.02);
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #004d40, #b8860b);
    opacity: 0;
    transition: opacity 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 20px 35px -10px rgba(0, 77, 64, 0.2);
}

.stat-card:hover::before {
    opacity: 1;
}

.stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.6rem;
    transition: all 0.2s ease;
    flex-shrink: 0;
}

.stat-card:hover .stat-icon {
    transform: scale(1.05) rotate(3deg);
}

.stat-details {
    flex: 1;
}

.stat-details h3 {
    font-size: 0.8rem;
    color: #64748b;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.25rem;
}

.stat-details .value {
    font-size: 1.8rem;
    font-weight: 800;
    color: #1e293b;
    line-height: 1.2;
    margin-bottom: 0.2rem;
}

.stat-badge {
    display: inline-block;
    font-size: 0.7rem;
    padding: 0.2rem 0.8rem;
    background: #f1f5f9;
    border-radius: 40px;
    color: #475569;
    font-weight: 600;
}

.stat-badge.warning {
    background: #fff3e0;
    color: #b8860b;
}

.stat-badge.danger {
    background: #fee2e2;
    color: #b91c1c;
}

.stat-badge.success {
    background: #e8f5e9;
    color: #004d40;
}

/* Responsive */
@media (max-width: 1200px) {
    .stats-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

@media (max-width: 992px) {
    .stats-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
    }
    
    .stat-card {
        padding: 1.2rem;
    }
    
    .stat-details .value {
        font-size: 1.5rem;
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
}
    </style>
</head>
<body>
    <?php include '../includes/sidebar.php'; ?>

    <div class="main-content">
        <!-- Header -->
        <div class="page-header">
            <h1>
                <i class="fa-solid fa-warehouse"></i>
                Inventory Management
            </h1>
            <div class="header-actions">
                <?php 
                if (function_exists('renderNotificationBell')) {
                    renderNotificationBell($conn); 
                }
                ?>
                <button class="btn btn-primary" onclick="openModal('addProductModal')">
                    <i class="fa-solid fa-plus"></i> New Medicine
                </button>
            </div>
        </div>

        <!-- Messages -->
        <?php if ($message): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-circle-check"></i> <?php echo htmlspecialchars($message); ?>
        </div>
        <?php endif; ?>
        
        <?php if ($error && strpos($error, 'BATCH_IN_USE:') === 0):
            // Parse: BATCH_IN_USE:{count}:{batch_number}:{batch_id}
            $parts     = explode(':', $error, 4);
            $in_use_count  = (int)($parts[1] ?? 0);
            $in_use_batch  = $parts[2] ?? '';
            $in_use_id     = (int)($parts[3] ?? 0);
        ?>
        <div class="alert alert-error" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:.8rem;">
            <span>
                <i class="fa-solid fa-circle-exclamation"></i>
                Cannot delete batch <strong><code><?php echo htmlspecialchars($in_use_batch); ?></code></strong> — it is referenced in
                <strong><?php echo $in_use_count; ?> sale record(s)</strong>.
            </span>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Force-delete this batch and reassign its sale records? This cannot be undone.');">
                <input type="hidden" name="action"       value="delete_batch">
                <input type="hidden" name="batch_id"     value="<?php echo $in_use_id; ?>">
                <input type="hidden" name="force_delete" value="1">
                <button type="submit" style="padding:.45rem 1.1rem;background:#dc2626;color:#fff;border:none;border-radius:9px;font-weight:700;font-size:.85rem;cursor:pointer;">
                    <i class="fa-solid fa-trash"></i> Force Delete
                </button>
            </form>
        </div>
        <?php elseif ($error): ?>
        <div class="alert alert-error">
            <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

       <!-- Statistics Cards - Matching User Management Style -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-pills"></i>
        </div>
        <div class="stat-details">
            <h3>Total Products</h3>
            <div class="value"><?php echo $total_products; ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-exclamation-triangle"></i>
        </div>
        <div class="stat-details">
            <h3>Low Stock</h3>
            <div class="value"><?php echo $low_stock_count; ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-circle-exclamation"></i>
        </div>
        <div class="stat-details">
            <h3>Out of Stock</h3>
            <div class="value"><?php echo $out_of_stock_count; ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-clock"></i>
        </div>
        <div class="stat-details">
            <h3>Near Expiry</h3>
            <div class="value"><?php echo $near_expiry_count; ?></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background: #e8f5e9; color: #004d40;">
            <i class="fa-solid fa-calendar-xmark"></i>
        </div>
        <div class="stat-details">
            <h3>Expired</h3>
            <div class="value"><?php echo $expired_count; ?></div>
        </div>
    </div>
</div>
        <!-- Filter Bar -->
        <div class="filter-bar">
            <div class="filter-group">
                <label><i class="fa-solid fa-search"></i> Search</label>
                <input type="text" id="searchInput" placeholder="Search products, batches, or categories..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="filter-group">
                <label><i class="fa-solid fa-tag"></i> Category</label>
                <select id="categoryFilter">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $category_filter == $cat['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['name']); ?> (<?php echo $cat['product_count']; ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Tabs Container -->
        <div class="tabs-container">
            <div class="tabs-header">
                <button class="tab-btn active" onclick="openTab(event, 'productsTab')">
                    <i class="fa-solid fa-pills"></i> Products
                </button>
                <button class="tab-btn" onclick="openTab(event, 'expiryTab')">
                    <i class="fa-solid fa-clock"></i> Expiry Tracking
                </button>
                <button class="tab-btn" onclick="openTab(event, 'categoriesTab')">
                    <i class="fa-solid fa-tags"></i> Categories
                </button>
            </div>

            <!-- Products Tab -->
            <div id="productsTab" class="tab-content active">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Base Unit</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="7" class="empty-state">
                                    <i class="fa-solid fa-box-open"></i>
                                    <p>No products found</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($products as $product): 
                                $stock_class = '';
                                $status_badge = 'status-good';
                                $status_text = 'In Stock';
                                
                                if ($product['total_stock'] <= 0) {
                                    $stock_class = 'stock-out';
                                    $status_badge = 'status-out';
                                    $status_text = 'Out of Stock';
                                } elseif ($product['total_stock'] < $product['low_stock_threshold']) {
                                    $stock_class = 'stock-low';
                                    $status_badge = 'status-low';
                                    $status_text = 'Low Stock';
                                }
                            ?>
                            <tr class="product-row"
                                data-name="<?php echo strtolower(htmlspecialchars($product['brand_name'])); ?>"
                                data-generic="<?php echo strtolower(htmlspecialchars($product['generic_name'] ?? '')); ?>"
                                data-barcode="<?php echo strtolower(htmlspecialchars($product['barcode'] ?? '')); ?>"
                                data-category="<?php echo strtolower(htmlspecialchars($product['category_name'] ?? '')); ?>"
                                data-unit="<?php echo strtolower(htmlspecialchars($product['base_unit'] ?? '')); ?>"
                                data-dosage="<?php echo strtolower(htmlspecialchars($product['dosage_form'] ?? '')); ?>"
                                data-cat-id="<?php echo (int)($product['category_id'] ?? 0); ?>">
                                <td>
                                    <a class="product-name-link" onclick="showProductDetails(<?php echo $product['id']; ?>)">
                                        <?php echo htmlspecialchars($product['brand_name']); ?>
                                    </a>
                                    <div class="product-generic"><?php echo htmlspecialchars($product['generic_name']); ?></div>
                                    <?php if (!empty($product['strength'])): ?>
                                    <div style="font-size:0.7rem; color:var(--gray-500);"><?php echo htmlspecialchars($product['strength']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="category-badge"><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></span>
                                </td>
                                <td><code><?php echo htmlspecialchars($product['base_unit']); ?></code></td>
                                <td><span class="price-value">₱<?php echo number_format($product['price'], 2); ?></span></td>
                                <td>
                                    <span class="stock-value <?php echo $stock_class; ?>">
                                        <?php echo $product['total_stock']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $status_badge; ?>">
                                        <?php echo $status_text; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-cell" onclick="event.stopPropagation();">
                                        <button class="action-btn btn-stock" onclick="openRestockModal(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars(addslashes($product['brand_name'])); ?>')">
                                            <i class="fa-solid fa-plus"></i> Restock
                                        </button>
                                        <button class="action-btn btn-delete" onclick="confirmDelete(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars(addslashes($product['brand_name'])); ?>')">
                                            <i class="fa-solid fa-trash"></i> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Expiry Tracking Tab -->
            <div id="expiryTab" class="tab-content">
                <div style="margin-bottom: 1rem; display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center;">
                    <button class="expiry-filter-btn active" data-filter="all" onclick="filterExpiry('all')">All</button>
                    <button class="expiry-filter-btn" data-filter="expired" onclick="filterExpiry('expired')" style="color:#c62828; border-color:#c62828;">Expired</button>
                    <button class="expiry-filter-btn" data-filter="near" onclick="filterExpiry('near')" style="color:#f57c00; border-color:#f57c00;">Near Expiry</button>
                    <button class="expiry-filter-btn" data-filter="good" onclick="filterExpiry('good')" style="color:#2e7d32; border-color:#2e7d32;">Good</button>
                </div>
                
                <div class="table-container">
                    <table class="expiry-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Batch #</th>
                                <th>Quantity</th>
                                <th>Expiry Date</th>
                                <th>Days Left</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $all_batches = $conn->query("
                                SELECT sb.*, p.brand_name, p.generic_name,
                                       DATEDIFF(sb.expiration_date, CURDATE()) as days_left
                                FROM stock_batches sb
                                JOIN products p ON p.id = sb.product_id
                                WHERE sb.quantity_base > 0
                                ORDER BY 
                                    CASE 
                                        WHEN sb.expiration_date <= CURDATE() THEN 1
                                        WHEN sb.expiration_date < DATE_ADD(CURDATE(), INTERVAL 1 MONTH) THEN 2
                                        ELSE 3
                                    END,
                                    sb.expiration_date ASC
                            ")->fetch_all(MYSQLI_ASSOC);
                            
                            foreach ($all_batches as $batch):
                                $days = (int)$batch['days_left'];
                                $status = 'good';
                                $status_class = 'status-good';
                                $status_text = 'Good';
                                
                                if ($days <= 0) {
                                    $status = 'expired';
                                    $status_class = 'status-expired';
                                    $status_text = 'Expired';
                                } elseif ($days < 30) {
                                    $status = 'near';
                                    $status_class = 'status-warning';
                                    $status_text = 'Near Expiry';
                                }
                            ?>
                            <tr class="expiry-row" data-status="<?php echo $status; ?>" data-name="<?php echo strtolower(htmlspecialchars($batch['brand_name'] . ' ' . $batch['generic_name'])); ?>">
                                <td>
                                    <strong><?php echo htmlspecialchars($batch['brand_name']); ?></strong>
                                    <br><small><?php echo htmlspecialchars($batch['generic_name']); ?></small>
                                </td>
                                <td><code><?php echo htmlspecialchars($batch['batch_number']); ?></code></td>
                                <td><?php echo $batch['quantity_base']; ?> units</td>
                                <td><?php echo date('M d, Y', strtotime($batch['expiration_date'])); ?></td>
                                <td>
                                    <?php if ($days <= 0): ?>
                                        <span style="color:#c62828; font-weight:700;">Expired <?php echo abs($days); ?> days ago</span>
                                    <?php else: ?>
                                        <?php echo $days; ?> days
                                    <?php endif; ?>
                                </td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                <td>
                                    <?php if ($status === 'expired' || $status === 'near'): ?>
                                    <button class="action-btn btn-delete" onclick="showRemoveConfirmModal(<?php echo $batch['id']; ?>, '<?php echo htmlspecialchars(addslashes($batch['batch_number'])); ?>', '<?php echo htmlspecialchars(addslashes($batch['brand_name'])); ?>', '<?php echo $status_text; ?>')">
                                        <i class="fa-solid fa-trash"></i> Remove
                                    </button>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($all_batches)): ?>
                            <tr><td colspan="7" style="text-align:center; padding: 2rem; color: #94a3b8;">No stock batches found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Categories Tab -->
            <div id="categoriesTab" class="tab-content">
                <div style="display: flex; justify-content: flex-end; margin-bottom: 1rem;">
                    <button class="btn btn-primary" onclick="openModal('addCategoryModal')">
                        <i class="fa-solid fa-plus"></i> Add Category
                    </button>
                </div>
                <div class="table-container">
                    <table class="expiry-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Category Name</th>
                                <th>Description</th>
                                <th>Products</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_categories as $cat): 
                                $product_count = $conn->query("SELECT COUNT(*) as count FROM products WHERE category_id = {$cat['id']}")->fetch_assoc()['count'];
                            ?>
                            <tr>
                                <td><?php echo $cat['id']; ?></td>
                                <td><strong><?php echo htmlspecialchars($cat['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($cat['description'] ?? '—'); ?></td>
                                <td><span class="badge"><?php echo $product_count; ?></span></td>
                                <td>
                                    <?php if ($product_count == 0): ?>
                                    <button type="button" class="action-btn btn-delete" 
                                        onclick="confirmCategoryDelete(<?php echo $cat['id']; ?>, '<?php echo htmlspecialchars(addslashes($cat['name'])); ?>')">
                                        <i class="fa-solid fa-trash"></i> Delete
                                    </button>
                                    <?php else: ?>
                                    <span class="badge" style="background: #e0e0e0;">In Use (<?php echo $product_count; ?> products)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Details Modal -->
    <div id="productDetailsModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <i class="fa-solid fa-circle-info"></i>
                    <span id="detailProductName"></span>
                </h2>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <button class="btn btn-outline" id="editProductBtn" onclick="editCurrentProduct()" title="Edit Medicine" style="padding: 0.5rem 1rem; font-size:0.85rem;">
                        <i class="fa-solid fa-pencil"></i> Edit
                    </button>
                    <button class="modal-close" onclick="closeModal('productDetailsModal')">✕</button>
                </div>
            </div>
            <div class="modal-body" id="productDetailsContent">
                <div style="text-align: center; padding: 3rem;">
                    <i class="fa-solid fa-spinner fa-spin fa-2x" style="color: var(--primary-green);"></i>
                    <p>Loading product details...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ADD NEW MEDICINE MODAL -->
    <div id="addProductModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h2>
                    <i class="fa-solid fa-plus-circle"></i>
                    Quick Add - New Medicine
                </h2>
                <button class="modal-close" onclick="closeModal('addProductModal')">✕</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_product">
                <div class="modal-body">
                    <!-- Basic Info -->
                    <div class="form-row">
                        <div class="form-group">
                            <label>Product Name *</label>
                            <input type="text" name="brand_name" class="form-control" required placeholder="e.g., Dolfenal">
                        </div>
                        <div class="form-group">
                            <label>Category *</label>
                            <select name="category_id" class="form-control" required>
                                <option value="">Select category</option>
                                <option value="1">Analgesic</option>
                                <option value="2">Antibiotic</option>
                                <option value="3">Antihistamine</option>
                                <option value="4">Vitamin</option>
                                <?php foreach ($all_categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Dosage Form *</label>
                            <select name="dosage_form" id="dosageFormSelect" class="form-control" required onchange="updateStrengthOptions()">
                                <option value="">Select Dosage Form</option>
                                <?php
                                $dosage_forms = [
                                    'Tablet', 'Capsule', 'Caplet', 'Syrup', 'Suspension', 'Drops (Oral)',
                                    'Eye Drops', 'Ear Drops', 'Nasal Spray', 'Injection (Ampule)', 'Injection (Vial)',
                                    'Cream', 'Ointment', 'Gel', 'Lotion', 'Suppository', 'Inhaler', 'Nebule',
                                    'Powder', 'Sachet', 'Patch (Transdermal)', 'Solution', 'Elixir', 'Emulsion'
                                ];
                                foreach ($dosage_forms as $form) {
                                    echo "<option value=\"$form\">$form</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Strength</label>
                            <select name="strength" id="strengthSelect" class="form-control">
                                <option value="">Select dosage form first</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Generic Name</label>
                            <input type="text" name="generic_name" class="form-control" placeholder="e.g., Mefenamic Acid">
                        </div>
                        <div class="form-group">
                            <label>Barcode</label>
                            <input type="text" name="barcode" class="form-control" placeholder="Optional">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Low Stock Threshold</label>
                            <input type="number" name="low_stock_threshold" class="form-control" value="10" min="1">
                        </div>
                        <div class="form-group"><!-- spacer --></div>
                    </div>

                    <!-- Combined Unit & Stock Section -->
                    <div class="stock-section">
                        <!-- WHAT YOU SELL -->
                        <div class="stock-header" style="background: #e8f5e9; color: var(--primary-green);">
                            <i class="fa-solid fa-tag"></i> What You Sell &nbsp;<small style="font-weight:400; color:var(--gray-500);">(Base Unit — smallest unit dispensed to patient)</small>
                        </div>
                        <div class="stock-row">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Base Unit <span style="color:var(--danger)">*</span> <small style="color:var(--gray-400); font-weight:400;">(smallest selling unit)</small></label>
                                    <select name="base_unit" id="baseUnitSelect" class="form-control" required>
                                        <option value="">Select Base Unit</option>
                                        <option value="Tablet">Tablet</option>
                                        <option value="Capsule">Capsule</option>
                                        <option value="Bottle">Bottle</option>
                                        <option value="Vial">Vial</option>
                                        <option value="Ampule">Ampule</option>
                                        <option value="Sachet">Sachet</option>
                                        <option value="Tube">Tube</option>
                                        <option value="Piece">Piece</option>
                                        <option value="Pack">Pack</option>
                                        <option value="Box">Box</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Selling Price per Base Unit (₱) <span style="color:var(--danger)">*</span></label>
                                    <input type="number" name="price" class="form-control" step="0.01" min="0" required placeholder="0.00">
                                </div>
                            </div>
                        </div>

                        <!-- WHAT YOU BUY -->
                        <div class="stock-header" style="background: #fff8e1; color: #b45309; border-top: 1px solid var(--gray-200);">
                            <i class="fa-solid fa-truck"></i> What You Buy &nbsp;<small style="font-weight:400; color:var(--gray-500);">(Purchase Unit — how stock arrives)</small>
                        </div>
                        <div class="stock-row">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Purchase Unit <small style="color:var(--gray-400); font-weight:400;">(how you bought it)</small></label>
                                    <select name="purchase_unit" id="purchaseUnitSelect" class="form-control">
                                        <option value="">Select Purchase Unit</option>
                                        <option value="Tablet">Tablet</option>
                                        <option value="Capsule">Capsule</option>
                                        <option value="Bottle">Bottle</option>
                                        <option value="Vial">Vial</option>
                                        <option value="Ampule">Ampule</option>
                                        <option value="Sachet">Sachet</option>
                                        <option value="Tube">Tube</option>
                                        <option value="Piece">Piece</option>
                                        <option value="Pack">Pack</option>
                                        <option value="Box">Box</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Conversion Factor <small style="color:var(--gray-400); font-weight:400;">(base units per purchase unit)</small></label>
                                    <input type="number" name="conversion_factor" id="conversionFactor" class="form-control" value="1" min="1" oninput="computeStock()">
                                    <small style="color:var(--gray-500); font-size:0.75rem;">e.g., 1 Box = 100 Tablets → enter <strong>100</strong></small>
                                </div>
                            </div>
                        </div>
                        <div class="stock-row">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Purchase Quantity <small style="color:var(--gray-400); font-weight:400;">(number of purchase units)</small></label>
                                    <input type="number" name="purchase_qty" id="purchaseQty" class="form-control" value="0" min="0" oninput="computeStock()">
                                </div>
                                <div class="form-group">
                                    <label>Cost per Purchase Unit (₱)</label>
                                    <input type="number" name="cost" id="costPerPurchase" class="form-control" step="0.01" min="0" required placeholder="0.00" oninput="computeStock()">
                                </div>
                            </div>
                        </div>

                        <!-- AUTO-COMPUTED -->
                        <div class="stock-header" style="background: #f0f4ff; color: #3730a3; border-top: 1px solid var(--gray-200);">
                            <i class="fa-solid fa-calculator"></i> Auto-Computed &nbsp;<small style="font-weight:400; color:var(--gray-500);">(read-only — calculated by system)</small>
                        </div>
                        <div class="stock-row" style="background: #fafbff;">
                            <div class="form-row">
                                <div class="form-group">
                                    <label style="color:#3730a3;">
                                        <i class="fa-solid fa-lock" style="font-size:0.7rem;"></i>
                                        Stock in Base Unit
                                        <small style="color:var(--gray-400); font-weight:400;">(purchase_qty × conversion_factor)</small>
                                    </label>
                                    <input type="number" name="initial_qty" id="stockBaseUnit" class="form-control"
                                           readonly placeholder="0"
                                           style="background:#e8eaf6; font-weight:700; color:#3730a3;">
                                </div>
                                <div class="form-group">
                                    <label style="color:#3730a3;">
                                        <i class="fa-solid fa-lock" style="font-size:0.7rem;"></i>
                                        Cost per Base Unit (₱)
                                        <small style="color:var(--gray-400); font-weight:400;">(cost ÷ conversion_factor)</small>
                                    </label>
                                    <input type="number" id="costPerBase" class="form-control"
                                           readonly placeholder="0.00"
                                           style="background:#e8eaf6; font-weight:700; color:#3730a3;">
                                </div>
                            </div>
                        </div>

                        <!-- EXPIRY & DATES -->
                        <div class="stock-header" style="border-top: 1px solid var(--gray-200);">
                            <i class="fa-solid fa-calendar"></i> Dates & Notes
                        </div>
                        <div class="stock-row">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Expiration Date</label>
                                    <input type="date" name="expiry_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+2 years')); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Date Received</label>
                                    <input type="date" name="date_received" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="stock-row">
                            <div class="form-group">
                                <label>Notes</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="e.g., Prescription required, store in cool dry place"></textarea>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1rem;">
                        <button type="button" class="btn btn-outline" onclick="closeModal('addProductModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-save"></i> Add Medicine
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- RESTOCK MODAL -->
    <div id="restockModal" class="modal">
        <div class="modal-content" style="max-width: 600px;">
            <div class="modal-header">
                <h2>
                    <i class="fa-solid fa-boxes"></i>
                    Restock: <span id="restockProductName"></span>
                </h2>
                <button class="modal-close" onclick="closeModal('restockModal')">✕</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_stock">
                <input type="hidden" name="product_id" id="restockProductId">
                <div class="modal-body">
                    <!-- Current Stock Info -->
                    <div class="current-stock-info">
                        <div class="info-row">
                            <span class="info-label">Product:</span>
                            <span class="info-value" id="restockProductInfo">Dolfenol (Tablet) - 500mg</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Current batch expires on:</span>
                            <span class="info-value" id="currentBatchExpiry">-</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">On hand:</span>
                            <span class="info-value" id="currentStock">0 units</span>
                        </div>
                    </div>

                    <!-- AUTO-GENERATED BATCH NUMBER -->
                    <div class="form-group">
                        <label>Batch Number (Auto-generated)</label>
                        <input type="text" class="form-control" id="batchNumberDisplay" value="Will be generated on save" readonly>
                        <div class="batch-preview">
                            <i class="fa-solid fa-info-circle"></i> New batch: <strong id="batchPreview"><?php echo generateBatchNumber($conn); ?></strong>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Receive In Unit</label>
                            <select name="received_unit" id="restockUnit" class="form-control" onchange="updateRestockConversion()">
                                <option value="">Same as Base Unit</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Conversion to Base <small style="color:var(--gray-400);">(auto-filled)</small></label>
                            <input type="number" name="restock_conversion" id="restockConversion" class="form-control" value="1" min="1" readonly style="background:#f0fdf4;">
                            <small id="restockConvHint" style="color:var(--gray-500);font-size:.75rem;"></small>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Quantity to Add *</label>
                            <input type="number" name="quantity" class="form-control" min="1" required id="restockQuantity" placeholder="0" oninput="updateRestockBasePreview()">
                        </div>
                        <div class="form-group">
                            <label>Expiration Date *</label>
                            <input type="date" name="expiry_date" class="form-control" required value="<?php echo date('Y-m-d', strtotime('+2 years')); ?>">
                        </div>
                    </div>
                    <div id="restockBasePreview" style="background:#e8f5e9;padding:.65rem 1rem;border-radius:.5rem;font-size:.85rem;color:#2e7d32;margin-bottom:1rem;display:none;">
                        <i class="fa-solid fa-calculator"></i> Will add <strong id="restockBaseQty">0</strong> base units to stock
                    </div>

                    <div class="form-group">
                        <label>Date Received</label>
                        <input type="date" name="date_received" class="form-control" value="<?php echo date('Y-m-d'); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label>Notes / Handling Instructions</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Optional notes for the receiving team"></textarea>
                    </div>

                    <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="button" class="btn btn-outline" onclick="closeModal('restockModal')">Cancel</button>
                        <button type="submit" class="btn btn-success">
                            <i class="fa-solid fa-check"></i> Submit Restock
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Category Modal -->
    <div id="addCategoryModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2>
                    <i class="fa-solid fa-tag"></i>
                    Add Category
                </h2>
                <button class="modal-close" onclick="closeModal('addCategoryModal')">✕</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_category">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Category Name *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                        <button type="button" class="btn btn-outline" onclick="closeModal('addCategoryModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Category</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div id="editProductModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h2>
                    <i class="fa-solid fa-pencil"></i>
                    Edit Medicine
                </h2>
                <button class="modal-close" onclick="closeModal('editProductModal')">✕</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit_product">
                <input type="hidden" name="product_id" id="editProductId">
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Product Name *</label>
                            <input type="text" name="brand_name" id="editBrandName" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Category *</label>
                            <select name="category_id" id="editCategoryId" class="form-control" required>
                                <option value="">Select category</option>
                                <?php foreach ($all_categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Dosage Form *</label>
                            <select name="dosage_form" id="editDosageForm" class="form-control" required onchange="updateEditStrengthOptions()">
                                <option value="">Select Dosage Form</option>
                                <?php
                                foreach ($dosage_forms as $form) {
                                    echo "<option value=\"$form\">$form</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Strength</label>
                            <select name="strength" id="editStrengthSelect" class="form-control">
                                <option value="">Select dosage form first</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Generic Name</label>
                            <input type="text" name="generic_name" id="editGenericName" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Barcode</label>
                            <input type="text" name="barcode" id="editBarcode" class="form-control">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Selling Price (₱) *</label>
                            <input type="number" name="price" id="editPrice" class="form-control" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label>Low Stock Threshold</label>
                            <input type="number" name="low_stock_threshold" id="editThreshold" class="form-control" min="1">
                        </div>
                    </div>
                    <div style="display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1rem;">
                        <button type="button" class="btn btn-outline" onclick="closeModal('editProductModal')">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-save"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Custom Confirm Dialog -->
    <div id="confirmDialog">
        <div style="background:#fff;border-radius:1.25rem;padding:2rem;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.25);text-align:center;">
            <div style="width:56px;height:56px;background:#fef2f2;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;">
                <i class="fa-solid fa-triangle-exclamation" style="color:#dc2626;font-size:1.5rem;"></i>
            </div>
            <h3 style="font-size:1.1rem;font-weight:700;color:#1f2937;margin-bottom:.75rem;">Confirm Delete</h3>
            <p id="confirmMessage" style="color:#6b7280;margin-bottom:1.5rem;font-size:.9rem;line-height:1.5;"></p>
            <div style="display:flex;gap:.75rem;justify-content:center;">
                <button id="confirmCancel" style="padding:.65rem 1.5rem;border:1px solid #d1d5db;background:#fff;border-radius:.75rem;font-weight:600;color:#374151;cursor:pointer;font-size:.9rem;">Cancel</button>
                <button id="confirmOk" style="padding:.65rem 1.5rem;background:#dc2626;border:none;border-radius:.75rem;font-weight:600;color:#fff;cursor:pointer;font-size:.9rem;">
                    <i class="fa-solid fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>

    <!-- Confirm Removal Modal -->
    <div id="removeConfirmModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:10000;align-items:center;justify-content:center;">
        <div style="background:#fff;border-radius:1.5rem;padding:2rem 2.5rem;max-width:440px;width:90%;box-shadow:0 25px 60px rgba(0,0,0,.3);text-align:center;animation:modalPop .25s ease;">
            <div style="width:64px;height:64px;background:#fef2f2;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.2rem;">
                <i class="fa-solid fa-trash-can" style="color:#dc2626;font-size:1.8rem;"></i>
            </div>
            <h3 style="font-size:1.2rem;font-weight:800;color:#1f2937;margin-bottom:.5rem;">Confirm Removal</h3>
            <p id="removeConfirmMessage" style="color:#6b7280;margin-bottom:1.5rem;font-size:.9rem;line-height:1.6;">Are you sure you want to permanently remove this item?</p>
            <div style="background:#fff7f7;border:1px solid #fecaca;border-radius:.75rem;padding:.75rem 1rem;margin-bottom:1.5rem;font-size:.85rem;color:#991b1b;">
                <i class="fa-solid fa-exclamation-circle"></i> This will permanently remove the batch from the database and cannot be undone.
            </div>
            <div style="display:flex;gap:.75rem;justify-content:center;">
                <button onclick="closeRemoveConfirmModal()" style="padding:.7rem 1.8rem;border:2px solid #d1d5db;background:#fff;border-radius:.9rem;font-weight:700;color:#374151;cursor:pointer;font-size:.9rem;transition:all .2s;">Cancel</button>
                <button id="removeConfirmOk" style="padding:.7rem 1.8rem;background:linear-gradient(135deg,#dc2626,#b91c1c);border:none;border-radius:.9rem;font-weight:700;color:#fff;cursor:pointer;font-size:.9rem;display:flex;align-items:center;gap:.5rem;transition:all .2s;">
                    <i class="fa-solid fa-trash"></i> Confirm Remove
                </button>
            </div>
        </div>
    </div>

    <script>
    // Global variables
    let currentTab = 'productsTab';
    let _expiryFilter = 'all';
    let searchTimeout;
    let currentProductId = null;
    let confirmCallback = null;

    // ============================================================
    // TAB FUNCTIONS
    // ============================================================
    function openTab(evt, tabId) {
        document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        evt.currentTarget.classList.add('active');
        
        currentTab = tabId;
        
        if (tabId === 'expiryTab') {
            _expiryFilter = 'all';
            document.querySelectorAll('.expiry-filter-btn').forEach(b => {
                b.classList.remove('active');
                if (b.dataset.filter === 'all') b.classList.add('active');
            });
        }
        
        performSearch();
    }

    // ============================================================
    // SEARCH FUNCTIONS
    // ============================================================
    function performSearch() {
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        
        if (!searchInput) return;
        
        const searchTerm = searchInput.value.toLowerCase().trim();
        const catId = categoryFilter ? categoryFilter.value : '';
        
        switch(currentTab) {
            case 'productsTab':
                searchProductsTab(searchTerm, catId);
                break;
            case 'expiryTab':
                searchExpiryTab(searchTerm, catId);
                break;
            case 'categoriesTab':
                searchCategoriesTab(searchTerm);
                break;
        }
    }

    function searchProductsTab(searchTerm, catId) {
        document.querySelectorAll('.product-row').forEach(row => {
            const matchesSearch = !searchTerm ||
                (row.dataset.name || '').includes(searchTerm) ||
                (row.dataset.generic || '').includes(searchTerm) ||
                (row.dataset.barcode || '').includes(searchTerm) ||
                (row.dataset.unit || '').includes(searchTerm) ||
                (row.dataset.dosage || '').includes(searchTerm) ||
                (row.dataset.category || '').includes(searchTerm);
            
            const matchesCat = !catId || row.dataset.catId === catId;
            
            row.style.display = (matchesSearch && matchesCat) ? '' : 'none';
        });
    }

    function searchExpiryTab(searchTerm, catId) {
        let selectedCategoryName = '';
        if (catId) {
            const categorySelect = document.getElementById('categoryFilter');
            const selectedOption = categorySelect?.options[categorySelect.selectedIndex];
            if (selectedOption) {
                selectedCategoryName = selectedOption.textContent.split(' (')[0].trim().toLowerCase();
            }
        }
        
        document.querySelectorAll('.expiry-row').forEach(row => {
            const matchesSearch = !searchTerm || (row.dataset.name || '').includes(searchTerm);
            const matchesFilter = _expiryFilter === 'all' || row.dataset.status === _expiryFilter;
            
            const categoryCell = row.querySelector('td:nth-child(2)');
            const categoryText = categoryCell ? categoryCell.textContent.trim().toLowerCase() : '';
            
            let matchesCategory = true;
            if (catId && selectedCategoryName) {
                matchesCategory = categoryText.includes(selectedCategoryName);
            }
            
            row.style.display = (matchesSearch && matchesFilter && matchesCategory) ? '' : 'none';
        });
    }

    function searchCategoriesTab(searchTerm) {
        document.querySelectorAll('#categoriesTab tbody tr').forEach(row => {
            const text = row.textContent.toLowerCase();
            const matchesSearch = !searchTerm || text.includes(searchTerm);
            row.style.display = matchesSearch ? '' : 'none';
        });
    }

    function filterExpiry(filter) {
        _expiryFilter = filter;
        document.querySelectorAll('.expiry-filter-btn').forEach(b => {
            b.classList.toggle('active', b.dataset.filter === filter);
        });
        performSearch();
    }

    // ============================================================
    // REMOVE CONFIRMATION MODAL
    // ============================================================
    let _pendingRemoveBatchId = null;

    function showRemoveConfirmModal(batchId, batchNum, productName, statusText) {
        _pendingRemoveBatchId = batchId;
        const msg = document.getElementById('removeConfirmMessage');
        if (msg) {
            msg.innerHTML = `Are you sure you want to permanently remove:<br><strong>${productName}</strong><br>Batch: <code>${batchNum}</code><br>Status: <span style="color:${statusText==='Expired'?'#dc2626':'#f57c00'};font-weight:700;">${statusText}</span>`;
        }
        const modal = document.getElementById('removeConfirmModal');
        if (modal) modal.style.display = 'flex';

        const okBtn = document.getElementById('removeConfirmOk');
        if (okBtn) {
            okBtn.onclick = function() {
                if (!_pendingRemoveBatchId) return;
                okBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Removing...';
                okBtn.disabled = true;

                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_batch">
                    <input type="hidden" name="batch_id" value="${_pendingRemoveBatchId}">
                `;
                document.body.appendChild(form);
                form.submit();
            };
        }
    }

    function closeRemoveConfirmModal() {
        const modal = document.getElementById('removeConfirmModal');
        if (modal) modal.style.display = 'none';
        _pendingRemoveBatchId = null;
    }

    document.addEventListener('click', function(e) {
        const modal = document.getElementById('removeConfirmModal');
        if (modal && e.target === modal) closeRemoveConfirmModal();
    });

    function debouncedSearch() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(performSearch, 300);
    }

    // ============================================================
    // DELETE FUNCTIONS
    // ============================================================
    function confirmDelete(id, name) {
        const message = `Are you sure you want to delete "${name}"?\n\nThis will permanently remove all batches and units.\nThis action CANNOT be undone!`;
        
        showConfirm(message, function() {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete_product';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = id;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            
            const btn = document.querySelector(`[onclick*="confirmDelete(${id}"]`);
            if (btn) {
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Deleting...';
                btn.disabled = true;
            }
            
            form.submit();
        });
    }

    function confirmCategoryDelete(id, name) {
        const message = `Delete category "${name}"? This cannot be undone.`;
        
        showConfirm(message, function() {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete_category';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = id;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        });
    }

    function showConfirm(message, callback) {
        const dialog = document.getElementById('confirmDialog');
        const msgEl = document.getElementById('confirmMessage');
        const okBtn = document.getElementById('confirmOk');
        const cancelBtn = document.getElementById('confirmCancel');
        
        if (!dialog || !msgEl || !okBtn || !cancelBtn) {
            if (confirm(message)) callback();
            return;
        }
        
        msgEl.textContent = message;
        confirmCallback = callback;
        dialog.style.display = 'flex';
        
        okBtn.onclick = function() {
            dialog.style.display = 'none';
            if (confirmCallback) {
                confirmCallback();
                confirmCallback = null;
            }
        };
        
        cancelBtn.onclick = function() {
            dialog.style.display = 'none';
            confirmCallback = null;
        };
    }

    // ============================================================
    // MODAL FUNCTIONS
    // ============================================================
    function openModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }

    // ============================================================
    // PRODUCT DETAILS FUNCTIONS
    // ============================================================
    function showProductDetails(productId) {
        currentProductId = productId;
        openModal('productDetailsModal');
        
        document.getElementById('productDetailsContent').innerHTML = `
            <div style="text-align: center; padding: 3rem;">
                <i class="fa-solid fa-spinner fa-spin fa-2x" style="color: var(--primary-green);"></i>
                <p>Loading product details...</p>
            </div>
        `;
        
        fetch('../ajax/get_product_details.php?product_id=' + productId)
            .then(response => response.text())
            .then(html => {
                document.getElementById('productDetailsContent').innerHTML = html;
                
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const nameElement = tempDiv.querySelector('h2');
                if (nameElement) {
                    document.getElementById('detailProductName').textContent = nameElement.textContent;
                }
            })
            .catch(error => {
                document.getElementById('productDetailsContent').innerHTML = `
                    <div class="empty-state">
                        <i class="fa-solid fa-exclamation-circle"></i>
                        <p>Error loading product details</p>
                    </div>
                `;
            });
    }

    function editCurrentProduct() {
        if (!currentProductId) return;
        
        fetch('../ajax/get_product_json.php?product_id=' + currentProductId)
            .then(r => r.json())
            .then(data => {
                if (!data) return;
                document.getElementById('editProductId').value = data.id || currentProductId;
                document.getElementById('editBrandName').value = data.brand_name || '';
                document.getElementById('editGenericName').value = data.generic_name || '';
                document.getElementById('editBarcode').value = data.barcode || '';
                document.getElementById('editCategoryId').value = data.category_id || '';
                document.getElementById('editPrice').value = data.price || '';
                document.getElementById('editThreshold').value = data.low_stock_threshold || 10;
                
                document.getElementById('editDosageForm').value = data.dosage_form || '';
                populateStrengthSelect(document.getElementById('editStrengthSelect'), data.dosage_form || '', data.strength || '');
                
                closeModal('productDetailsModal');
                openModal('editProductModal');
            })
            .catch(() => {
                document.getElementById('editProductId').value = currentProductId;
                closeModal('productDetailsModal');
                openModal('editProductModal');
            });
    }

    // ============================================================
    // STOCK FUNCTIONS
    // ============================================================
    function computeStock() {
        const qty = parseFloat(document.getElementById('purchaseQty').value) || 0;
        const conv = parseFloat(document.getElementById('conversionFactor').value) || 1;
        const cost = parseFloat(document.getElementById('costPerPurchase').value) || 0;

        document.getElementById('stockBaseUnit').value = (qty * conv).toFixed(0);
        document.getElementById('costPerBase').value = conv > 0 ? (cost / conv).toFixed(4) : '';
    }

    function openRestockModal(productId, productName) {
        document.getElementById('restockProductId').value = productId;
        document.getElementById('restockProductInfo').textContent = productName;
        document.getElementById('restockProductName').textContent = productName;

        const unitSel = document.getElementById('restockUnit');
        unitSel.innerHTML = '<option value="">Same as Base Unit</option>';
        document.getElementById('restockConversion').value = '1';
        document.getElementById('restockConvHint').textContent = '';
        document.getElementById('restockBasePreview').style.display = 'none';
        window._restockUnits = [];

        fetch('../ajax/get_product_json.php?product_id=' + productId)
            .then(r => r.json())
            .then(data => {
                if (!data) return;
                window.currentBaseUnit = data.base_unit || 'piece';
                document.getElementById('restockProductInfo').textContent = data.brand_name + ' (' + window.currentBaseUnit + ')';
                document.getElementById('currentStock').textContent = (data.total_stock || 0) + ' ' + window.currentBaseUnit;
                document.getElementById('currentBatchExpiry').textContent = data.next_expiry || 'No existing batch';
            });

        fetch('../ajax/get_product_units.php?product_id=' + productId)
            .then(r => r.json())
            .then(data => {
                window._restockUnits = data.units || [];
                window._restockBaseUnit = (data.product && data.product.base_unit) || 'piece';
                window._restockBasePrice = parseFloat((data.product && data.product.price) || 0);

                window._restockUnits.forEach(u => {
                    if (parseInt(u.conversion_to_base) > 1) {
                        const opt = document.createElement('option');
                        opt.value = u.unit_name;
                        opt.dataset.conv = u.conversion_to_base;
                        opt.textContent = u.unit_name + ' (= ' + u.conversion_to_base + ' ' + window._restockBaseUnit + ')';
                        unitSel.appendChild(opt);
                    }
                });
            });

        const date = new Date();
        const bpNum = date.getFullYear() + String(date.getMonth()+1).padStart(2,'0') + String(date.getDate()).padStart(2,'0') + '-' + Math.floor(Math.random()*900+100);
        document.getElementById('batchPreview').textContent = bpNum;

        openModal('restockModal');
    }

    function updateRestockConversion() {
        const sel = document.getElementById('restockUnit');
        const conv = parseInt(sel.selectedOptions[0]?.dataset?.conv || '1');
        document.getElementById('restockConversion').value = conv;
        const hint = document.getElementById('restockConvHint');
        if (conv > 1) {
            hint.textContent = '1 ' + sel.value + ' = ' + conv + ' ' + (window._restockBaseUnit || 'base units');
        } else {
            hint.textContent = '';
        }
        updateRestockBasePreview();
    }

    function updateRestockBasePreview() {
        const qty = parseInt(document.getElementById('restockQuantity').value || 0);
        const conv = parseInt(document.getElementById('restockConversion').value || 1);
        const base = qty * conv;
        const preview = document.getElementById('restockBasePreview');
        const baseQtyEl = document.getElementById('restockBaseQty');
        if (qty > 0) {
            preview.style.display = 'block';
            baseQtyEl.textContent = base + ' ' + (window._restockBaseUnit || 'base unit(s)');
        } else {
            preview.style.display = 'none';
        }
    }

    // ============================================================
    // STRENGTH OPTIONS
    // ============================================================
    const strengthMap = {
        'Tablet': ['125 mg','250 mg','500 mg','650 mg','1000 mg'],
        'Capsule': ['125 mg','250 mg','500 mg','650 mg','1000 mg'],
        'Caplet': ['125 mg','250 mg','500 mg','650 mg','1000 mg'],
        'Syrup': ['100 mg/5ml','125 mg/5ml','200 mg/5ml','250 mg/5ml'],
        'Suspension': ['100 mg/5ml','125 mg/5ml','200 mg/5ml','250 mg/5ml'],
        'Drops (Oral)': ['100 mg/ml','125 mg/ml','50 mg/ml'],
        'Eye Drops': ['0.1%','0.3%','0.5%','1%'],
        'Ear Drops': ['0.1%','0.3%','0.5%','1%'],
        'Nasal Spray': ['50 mcg','100 mcg','0.05%','0.1%'],
        'Injection (Ampule)': ['250 mg/2ml','500 mg/2ml','1g/10ml'],
        'Injection (Vial)': ['250 mg/2ml','500 mg/2ml','1g/10ml'],
        'Cream': ['1%','2%','5%','10%'],
        'Ointment': ['1%','2%','5%','10%'],
        'Gel': ['1%','2%','5%'],
        'Lotion': ['1%','2%','5%'],
        'Suppository': ['125 mg','250 mg','500 mg'],
        'Inhaler': ['100 mcg','200 mcg','400 mcg'],
        'Nebule': ['0.5 mg/ml','1 mg/ml','2.5 mg/2.5ml'],
        'Powder': ['125 mg','250 mg','500 mg'],
        'Sachet': ['250 mg','500 mg','1 g'],
        'Patch (Transdermal)': ['5 mg/24hr','10 mg/24hr','25 mcg/hr','50 mcg/hr'],
        'Solution': ['125 mg/5ml','250 mg/5ml','1%','2%'],
        'Elixir': ['125 mg/5ml','250 mg/5ml'],
        'Emulsion': ['125 mg/5ml','250 mg/5ml'],
    };

    function populateStrengthSelect(selectEl, dosageForm, currentVal) {
        const opts = strengthMap[dosageForm] || [];
        selectEl.innerHTML = '<option value="">Select Strength</option>';
        opts.forEach(opt => {
            const o = document.createElement('option');
            o.value = opt;
            o.textContent = opt;
            if (opt === currentVal) o.selected = true;
            selectEl.appendChild(o);
        });
        if (currentVal && !opts.includes(currentVal)) {
            const o = document.createElement('option');
            o.value = currentVal;
            o.textContent = currentVal;
            o.selected = true;
            selectEl.appendChild(o);
        }
    }

    function updateStrengthOptions() {
        const dosage = document.getElementById('dosageFormSelect').value;
        populateStrengthSelect(document.getElementById('strengthSelect'), dosage, '');
    }

    function updateEditStrengthOptions() {
        const dosage = document.getElementById('editDosageForm').value;
        const curVal = document.getElementById('editStrengthSelect').value;
        populateStrengthSelect(document.getElementById('editStrengthSelect'), dosage, curVal);
    }

    // ============================================================
    // INITIALIZATION
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        
        if (searchInput) {
            searchInput.addEventListener('input', debouncedSearch);
        }
        
        if (categoryFilter) {
            categoryFilter.addEventListener('change', performSearch);
        }
        
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal.active').forEach(modal => {
                    modal.classList.remove('active');
                });
                document.body.style.overflow = '';
                
                const dialog = document.getElementById('confirmDialog');
                if (dialog && dialog.style.display === 'flex') {
                    dialog.style.display = 'none';
                    confirmCallback = null;
                }
                
                const removeModal = document.getElementById('removeConfirmModal');
                if (removeModal && removeModal.style.display === 'flex') {
                    removeModal.style.display = 'none';
                }
            }
        });
        
        currentTab = 'productsTab';
    });
    </script>

    <?php 
    if (function_exists('renderNotificationPanel')) {
        renderNotificationPanel($conn); 
    }
    ?>
    
</body>
</html>