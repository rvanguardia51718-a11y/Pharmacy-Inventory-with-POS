<?php
/**
 * actions/pos_process.php
 * Processes a POS sale:
 *  - Validates stock using total base units across ALL non-expired batches
 *  - Deducts via TRUE FIFO (oldest expiry first, across multiple batches)
 *  - Supports multi-unit sales (tablet/blister/box → converted to base units)
 *  - Prevents overselling / negative stock
 */
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/inventory_helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid method']);
    exit;
}

$input = file_get_contents('php://input');
$data  = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON: ' . json_last_error_msg()]);
    exit;
}

if (!$data || empty($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Empty cart']);
    exit;
}

$user_id = (int)($_SESSION['user_id'] ?? 0);
if ($user_id === 0) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

$total       = (float)($data['total_amount']       ?? 0);
$discount    = (float)($data['discount']           ?? 0);
$tax         = (float)($data['tax']                ?? 0);
$grand       = (float)($data['grand_total']         ?? 0);
$cash        = (float)($data['cash_received']       ?? 0);
$change      = (float)($data['change_amount']       ?? 0);
$vat_sales   = (float)($data['vat_sales']           ?? 0);
$vat_exempt  = (float)($data['vat_exempt_sales']    ?? 0);
$vat_zero    = (float)($data['vat_zero_rated_sales'] ?? 0);
$vat_amount  = (float)($data['vat_amount']          ?? 0);

$pos_sn = 'S4-' . rand(10000000, 99999999);
$tm_num = 'TM#' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

try {
    $conn->begin_transaction();

    // ── Pre-validate ALL items before touching the DB ───────
    foreach ($data['items'] as $item) {
        $product_id       = (int)$item['id'];
        $quantity_sold    = (int)($item['quantity_sold']    ?? $item['quantity'] ?? 1);
        $unit_sold        = trim($item['unit_sold']         ?? '');
        $quantity_in_base = (int)($item['quantity_in_base'] ?? 0);

        if ($quantity_in_base <= 0) {
            $quantity_in_base = !empty($unit_sold)
                ? toBaseUnits($conn, $product_id, $quantity_sold, $unit_sold)
                : $quantity_sold;
        }

        // Total stock across ALL non-expired batches
        $avail_stmt = $conn->prepare(
            "SELECT COALESCE(SUM(quantity_base),0) as total
             FROM stock_batches
             WHERE product_id=? AND quantity_base>0 AND expiration_date>=CURDATE()"
        );
        $avail_stmt->bind_param("i", $product_id);
        $avail_stmt->execute();
        $avail = (int)$avail_stmt->get_result()->fetch_assoc()['total'];
        $avail_stmt->close();

        if ($quantity_in_base > $avail) {
            $pname_stmt = $conn->prepare("SELECT brand_name FROM products WHERE id=?");
            $pname_stmt->bind_param("i", $product_id);
            $pname_stmt->execute();
            $pname = $pname_stmt->get_result()->fetch_assoc()['brand_name'] ?? "Product #$product_id";
            $pname_stmt->close();
            throw new Exception("Insufficient stock for $pname: need $quantity_in_base base units, only $avail available.");
        }
    }

    // ── Insert sale header ───────────────────────────────────
    $stmt = $conn->prepare("
        INSERT INTO sales (
            user_id, total_amount, discount, tax, grand_total,
            cash_received, change_amount, vat_sales, vat_exempt_sales,
            vat_zero_rated_sales, vat_amount, pos_sn, tm_number
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    ");
    $stmt->bind_param(
        "idddddddddsss",
        $user_id, $total, $discount, $tax, $grand,
        $cash, $change, $vat_sales, $vat_exempt,
        $vat_zero, $vat_amount, $pos_sn, $tm_num
    );
    $stmt->execute();
    $sale_id = $conn->insert_id;
    $stmt->close();

    // ── Process each item ────────────────────────────────────
    foreach ($data['items'] as $item) {
        $product_id       = (int)$item['id'];
        $quantity_sold    = (int)($item['quantity_sold']    ?? $item['quantity'] ?? 1);
        $unit_sold        = trim($item['unit_sold']         ?? '');
        $unit_price       = (float)($item['unit_price']     ?? $item['price'] ?? 0);
        $subtotal         = (float)($item['subtotal']       ?? ($quantity_sold * $unit_price));
        $vat_type         = $conn->real_escape_string($item['vat_type'] ?? 'vatable');
        $quantity_in_base = (int)($item['quantity_in_base'] ?? 0);

        if ($quantity_in_base <= 0) {
            $quantity_in_base = !empty($unit_sold)
                ? toBaseUnits($conn, $product_id, $quantity_sold, $unit_sold)
                : $quantity_sold;
        }

        // TRUE FIFO — deduct from oldest expiry batches first
        $remaining      = $quantity_in_base;
        $first_batch_id = null;

        $fifo_stmt = $conn->prepare(
            "SELECT id, quantity_base
             FROM stock_batches
             WHERE product_id=? AND quantity_base>0 AND expiration_date>=CURDATE()
             ORDER BY expiration_date ASC, id ASC"
        );
        $fifo_stmt->bind_param("i", $product_id);
        $fifo_stmt->execute();
        $batches = $fifo_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $fifo_stmt->close();

        foreach ($batches as $batch) {
            if ($remaining <= 0) break;
            $take = min($remaining, (int)$batch['quantity_base']);

            $upd = $conn->prepare(
                "UPDATE stock_batches SET quantity_base=quantity_base-? WHERE id=? AND quantity_base>=?"
            );
            $upd->bind_param("iii", $take, $batch['id'], $take);
            $upd->execute();
            if ($upd->affected_rows === 0) {
                $upd->close();
                throw new Exception("Race condition on batch {$batch['id']}. Please retry.");
            }
            $upd->close();

            if ($first_batch_id === null) $first_batch_id = $batch['id'];
            $remaining -= $take;
        }

        if ($remaining > 0) {
            throw new Exception("Stock depleted mid-transaction for product ID $product_id");
        }

        if (empty($unit_sold)) {
            $bu_stmt = $conn->prepare("SELECT base_unit FROM products WHERE id=?");
            $bu_stmt->bind_param("i", $product_id);
            $bu_stmt->execute();
            $unit_sold = $bu_stmt->get_result()->fetch_assoc()['base_unit'] ?? 'piece';
            $bu_stmt->close();
        }

        $item_stmt = $conn->prepare("
            INSERT INTO sale_items
                (sale_id, product_id, batch_id, unit_sold,
                 quantity_sold, quantity_in_base, unit_price, subtotal, vat_type)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");
        $item_stmt->bind_param(
            "iiisiiids",
            $sale_id, $product_id, $first_batch_id, $unit_sold,
            $quantity_sold, $quantity_in_base, $unit_price, $subtotal, $vat_type
        );
        $item_stmt->execute();
        $item_stmt->close();
    }

    // ── Activity log ─────────────────────────────────────────
    $log_desc = "Sale #$sale_id | Total: ₱" . number_format($grand, 2);
    $log_stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, 'Sale', ?)");
    $log_stmt->bind_param("is", $user_id, $log_desc);
    $log_stmt->execute();
    $log_stmt->close();

    $conn->commit();

    echo json_encode([
        'success'        => true,
        'sale_id'        => $sale_id,
        'receipt_number' => $pos_sn . '-' . $sale_id,
        'message'        => "Sale #$sale_id completed successfully!"
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
