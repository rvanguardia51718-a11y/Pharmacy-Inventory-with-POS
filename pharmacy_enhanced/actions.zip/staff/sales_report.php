<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/notifications.php';

// Staff only — redirect admins to full reports
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
$current_user_id = (int)$_SESSION['user_id'];
$user_name       = $_SESSION['full_name'] ?? 'Staff';

$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date   = $_GET['end_date']   ?? date('Y-m-d');

// My sales in date range
$stmt = $conn->prepare("
    SELECT s.id, s.sale_date, s.total_amount, s.discount, s.tax, s.grand_total,
           s.cash_received, s.change_amount
    FROM sales s
    WHERE s.user_id = ?
      AND DATE(s.sale_date) BETWEEN ? AND ?
    ORDER BY s.sale_date DESC
");
$stmt->bind_param("iss", $current_user_id, $start_date, $end_date);
$stmt->execute();
$sales_result = $stmt->get_result();

$sales         = [];
$total_revenue = 0;
$total_discount = 0;
while ($row = $sales_result->fetch_assoc()) {
    $sales[]        = $row;
    $total_revenue  += $row['grand_total'];
    $total_discount += $row['discount'];
}
$stmt->close();

$avg_sale = count($sales) > 0 ? $total_revenue / count($sales) : 0;

// Last 7 days chart data for this staff
$r = $conn->prepare("
    SELECT DATE(sale_date) as d, COUNT(*) as tx_count, COALESCE(SUM(grand_total),0) as total_sales
    FROM sales
    WHERE user_id = ? AND sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(sale_date)
");
$r->bind_param("i", $current_user_id);
$r->execute();
$chart_res = $r->get_result();
$r->close();

$chart_labels = [];
$chart_tx     = [];
$chart_sales  = [];
$chart_map    = [];
while ($row = $chart_res->fetch_assoc()) $chart_map[$row['d']] = $row;
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_labels[] = date('D, M j', strtotime($date));
    $chart_tx[]     = (int)($chart_map[$date]['tx_count'] ?? 0);
    $chart_sales[]  = (float)($chart_map[$date]['total_sales'] ?? 0);
}

function formatPHP($a) { return '₱' . number_format($a, 2); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Sales Report | CAD Crest</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #004d40;
            --gold:    #b8860b;
            --teal:    #00897b;
        }
        body { background: #f8fafc; }

        /* ── Page Header ── */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .page-title { margin: 0; color: var(--primary); font-size: 1.6rem; font-weight: 800; }
        .page-subtitle { color: #64748b; font-size: 0.9rem; margin: 4px 0 0; }

        /* ── Summary Cards ── */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.2rem;
            margin-bottom: 2rem;
        }
        .summary-card {
            background: #fff;
            border-radius: 20px;
            padding: 1.3rem 1.5rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 1rem;
            border: 1px solid rgba(0,0,0,0.03);
            transition: transform .2s;
        }
        .summary-card:hover { transform: translateY(-3px); }
        .sc-icon {
            width: 52px; height: 52px;
            border-radius: 14px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.3rem; flex-shrink: 0;
        }
        .sc-icon.green  { background: #ecfdf5; color: #10b981; }
        .sc-icon.gold   { background: #fffbeb; color: #d97706; }
        .sc-icon.teal   { background: #f0fdfa; color: #0d9488; }
        .sc-icon.purple { background: #f5f3ff; color: #7c3aed; }
        .sc-label { font-size: 0.75rem; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; }
        .sc-value { font-size: 1.4rem; font-weight: 800; color: #1e293b; margin: 2px 0 0; }

        /* ── Filter Bar ── */
        .filter-bar {
            background: #fff;
            border-radius: 16px;
            padding: 1rem 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.04);
            display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
        }
        .filter-bar label { font-size: 0.85rem; font-weight: 600; color: #64748b; }
        .filter-bar input[type="date"] {
            padding: 0.45rem 0.8rem;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            font-size: 0.9rem;
            color: #334155;
            outline: none;
            transition: border-color .2s;
        }
        .filter-bar input[type="date"]:focus { border-color: var(--primary); }
        .btn-filter {
            padding: 0.45rem 1.2rem;
            background: var(--primary);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: background .2s;
        }
        .btn-filter:hover { background: #00695c; }

        /* ── Charts Row ── */
        .charts-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: #fff;
            border-radius: 20px;
            padding: 1.4rem 1.5rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }
        .chart-card-title {
            font-size: 0.85rem; font-weight: 700; color: #475569;
            text-transform: uppercase; letter-spacing: .05em; margin: 0 0 1rem;
        }
        @media (max-width: 768px) { .charts-row { grid-template-columns: 1fr; } }

        /* ── Table ── */
        .table-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        .table-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid #f1f5f9;
        }
        .table-title { font-size: 1rem; font-weight: 700; color: #1e293b; margin: 0; }
        .badge {
            background: #f1f5f9; color: #64748b;
            padding: 0.3rem 0.8rem; border-radius: 999px; font-size: 0.8rem; font-weight: 600;
        }
        .modern-table { width: 100%; border-collapse: collapse; }
        .modern-table th {
            background: #f8fafc; color: #64748b;
            font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em;
            padding: 0.8rem 1rem; text-align: left; border-bottom: 1px solid #f1f5f9;
        }
        .modern-table td { padding: 0.85rem 1rem; border-bottom: 1px solid #f8fafc; font-size: 0.9rem; }
        .modern-table tbody tr { cursor: pointer; transition: background .15s; }
        .modern-table tbody tr:hover { background: #f8fafc; }
        .modern-table tfoot td { padding: .85rem 1rem; font-weight: 700; background: #f8fafc; }
        .tx-id { font-family: monospace; font-weight: 700; color: var(--primary); }
        .amount { font-weight: 700; color: var(--primary); }
        .discount { color: #ef4444; }
        .text-right { text-align: right; }
        .empty-state {
            text-align: center; padding: 3rem 1rem; color: #94a3b8;
        }
        .empty-state i { font-size: 2.5rem; display: block; margin-bottom: .5rem; }

        /* ── Modal ── */
        #txModal {
            display: none;
            position: fixed; inset: 0; z-index: 9999;
            background: rgba(0,0,0,.45);
            align-items: center; justify-content: center;
        }
        #txModal.open { display: flex; }
        .modal-box {
            background: #fff;
            border-radius: 20px;
            width: 90%; max-width: 600px;
            max-height: 85vh;
            overflow-y: auto;
            box-shadow: 0 25px 60px rgba(0,0,0,.2);
            animation: slideUp .25s ease;
        }
        @keyframes slideUp { from { transform: translateY(30px); opacity:0; } to { transform: translateY(0); opacity:1; } }
        .modal-head {
            display: flex; align-items: center; justify-content: space-between;
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid #f1f5f9;
            position: sticky; top: 0; background: #fff; z-index: 1;
        }
        .modal-head h3 { margin: 0; font-size: 1rem; font-weight: 700; color: #1e293b; }
        .modal-close {
            background: #f1f5f9; border: none; border-radius: 8px;
            width: 32px; height: 32px; cursor: pointer; font-size: 1rem;
            display: flex; align-items: center; justify-content: center; color: #64748b;
            transition: background .2s;
        }
        .modal-close:hover { background: #e2e8f0; }
        .modal-body { padding: 1.5rem; }
        .modal-meta { display: grid; grid-template-columns: 1fr 1fr; gap: .8rem; margin-bottom: 1.2rem; }
        .meta-item label { font-size: .75rem; color: #94a3b8; text-transform: uppercase; font-weight: 600; }
        .meta-item span { display: block; font-size: .95rem; font-weight: 600; color: #334155; margin-top: 2px; }
        .items-table { width: 100%; border-collapse: collapse; margin-top: .5rem; }
        .items-table th { font-size: .75rem; color: #64748b; font-weight: 700; text-transform: uppercase; padding: .5rem .6rem; text-align: left; border-bottom: 2px solid #f1f5f9; }
        .items-table td { padding: .6rem .6rem; font-size: .88rem; border-bottom: 1px solid #f8fafc; }
        .items-table tfoot td { font-weight: 700; padding: .7rem .6rem; border-top: 2px solid #f1f5f9; }
        .modal-totals { background: #f8fafc; border-radius: 12px; padding: 1rem 1.2rem; margin-top: 1rem; }
        .total-row { display: flex; justify-content: space-between; padding: .25rem 0; font-size: .9rem; }
        .total-row.grand { font-weight: 800; font-size: 1rem; color: var(--primary); border-top: 1px solid #e2e8f0; padding-top: .5rem; margin-top: .25rem; }
        #modalLoading { text-align: center; padding: 2rem; color: #94a3b8; }
    </style>
</head>
<body>
<?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

<div class="main-content">
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title"><i class="fa-solid fa-chart-bar" style="color:var(--gold);margin-right:.5rem;"></i>My Sales Report</h1>
            <p class="page-subtitle">Personal transaction history and performance analytics</p>
        </div>
        <span style="font-size:.85rem;color:#64748b;background:#fff;padding:.4rem .9rem;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.06);">
            <i class="fa-regular fa-calendar"></i> <?php echo date('F j, Y'); ?>
        </span>
    </div>

    <!-- Summary Cards -->
    <div class="summary-grid">
        <div class="summary-card">
            <div class="sc-icon green"><i class="fa-solid fa-peso-sign"></i></div>
            <div>
                <div class="sc-label">Total Revenue</div>
                <div class="sc-value"><?php echo formatPHP($total_revenue); ?></div>
            </div>
        </div>
        <div class="summary-card">
            <div class="sc-icon gold"><i class="fa-solid fa-receipt"></i></div>
            <div>
                <div class="sc-label">Total Transactions</div>
                <div class="sc-value"><?php echo count($sales); ?></div>
            </div>
        </div>
        <div class="summary-card">
            <div class="sc-icon teal"><i class="fa-solid fa-chart-line"></i></div>
            <div>
                <div class="sc-label">Average Sale</div>
                <div class="sc-value"><?php echo formatPHP($avg_sale); ?></div>
            </div>
        </div>
        <div class="summary-card">
            <div class="sc-icon purple"><i class="fa-solid fa-tag"></i></div>
            <div>
                <div class="sc-label">Total Discount Given</div>
                <div class="sc-value"><?php echo formatPHP($total_discount); ?></div>
            </div>
        </div>
    </div>

    <!-- Filter Bar -->
    <form class="filter-bar" method="GET" action="">
        <label>From</label>
        <input type="date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
        <label>To</label>
        <input type="date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
        <button type="submit" class="btn-filter"><i class="fa-solid fa-filter"></i> Apply Filter</button>
        <a href="sales_report.php" style="font-size:.85rem;color:#64748b;text-decoration:none;margin-left:.5rem;">Reset</a>
    </form>

    <!-- Charts -->
    <div class="charts-row">
        <div class="chart-card">
            <p class="chart-card-title"><i class="fa-solid fa-chart-column" style="color:var(--primary);margin-right:.4rem;"></i>Transactions — Last 7 Days</p>
            <div style="position:relative;height:220px;">
                <canvas id="txChart"></canvas>
            </div>
        </div>
        <div class="chart-card">
            <p class="chart-card-title"><i class="fa-solid fa-chart-area" style="color:var(--gold);margin-right:.4rem;"></i>Sales Revenue — Last 7 Days</p>
            <div style="position:relative;height:220px;">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Transactions Table -->
    <div class="table-card">
        <div class="table-header">
            <h3 class="table-title"><i class="fa-regular fa-rectangle-list" style="margin-right:.4rem;color:var(--primary);"></i>Transaction Details</h3>
            <span class="badge"><i class="fa-regular fa-file-lines"></i> <?php echo count($sales); ?> records</span>
        </div>
        <div style="overflow-x:auto;">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>ID</th>
                        <th class="text-right">Subtotal</th>
                        <th class="text-right">Discount</th>
                        <th class="text-right">Tax</th>
                        <th class="text-right">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sales)): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="fa-regular fa-folder-open"></i>
                                <p>No transactions found for this period.</p>
                            </div>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($sales as $s): ?>
                        <tr onclick="openTxModal(<?php echo $s['id']; ?>)" title="Click to view details">
                            <td><?php echo date('M d, Y', strtotime($s['sale_date'])); ?></td>
                            <td><?php echo date('h:i A', strtotime($s['sale_date'])); ?></td>
                            <td><span class="tx-id">#<?php echo str_pad($s['id'], 6, '0', STR_PAD_LEFT); ?></span></td>
                            <td class="text-right"><?php echo formatPHP($s['total_amount']); ?></td>
                            <td class="text-right discount">-<?php echo formatPHP($s['discount']); ?></td>
                            <td class="text-right"><?php echo formatPHP($s['tax']); ?></td>
                            <td class="text-right amount"><?php echo formatPHP($s['grand_total']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <?php if (!empty($sales)): ?>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Totals</strong></td>
                        <td class="text-right"><strong><?php echo formatPHP(array_sum(array_column($sales,'total_amount'))); ?></strong></td>
                        <td class="text-right discount"><strong>-<?php echo formatPHP(array_sum(array_column($sales,'discount'))); ?></strong></td>
                        <td class="text-right"><strong><?php echo formatPHP(array_sum(array_column($sales,'tax'))); ?></strong></td>
                        <td class="text-right amount"><strong><?php echo formatPHP($total_revenue); ?></strong></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<!-- Transaction Detail Modal -->
<div id="txModal">
    <div class="modal-box">
        <div class="modal-head">
            <h3 id="modalTitle"><i class="fa-solid fa-receipt" style="color:var(--primary);margin-right:.5rem;"></i>Transaction Details</h3>
            <button class="modal-close" onclick="closeTxModal()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body" id="modalBody">
            <div id="modalLoading"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</div>
        </div>
    </div>
</div>

<script>
// ── Charts ────────────────────────────────────────────────────
const labels   = <?php echo json_encode($chart_labels); ?>;
const txData   = <?php echo json_encode($chart_tx); ?>;
const revData  = <?php echo json_encode($chart_sales); ?>;

const tooltipDef = {
    backgroundColor: '#1f2937', titleColor: '#f9fafb',
    bodyColor: '#e5e7eb', padding: 12, cornerRadius: 8
};

// Transactions bar chart
new Chart(document.getElementById('txChart'), {
    type: 'bar',
    data: {
        labels,
        datasets: [{
            label: 'Transactions',
            data: txData,
            backgroundColor: 'rgba(0,77,64,.8)',
            borderColor: '#004d40',
            borderWidth: 2,
            borderRadius: 8,
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: { ...tooltipDef, callbacks: { label: c => ' ' + c.parsed.y + ' transactions' } }
        },
        scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,.04)' }, ticks: { stepSize: 1 } },
            x: { grid: { display: false } }
        },
        animation: { duration: 1200, easing: 'easeOutBounce' }
    }
});

// Revenue area chart
(function() {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 220);
    grad.addColorStop(0, 'rgba(184,134,11,.25)');
    grad.addColorStop(1, 'rgba(184,134,11,0)');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Revenue (₱)',
                data: revData,
                borderColor: '#b8860b',
                backgroundColor: grad,
                borderWidth: 3,
                pointBackgroundColor: '#b8860b',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 8,
                tension: 0.4,
                fill: true,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { ...tooltipDef, callbacks: { label: c => ' ₱' + c.parsed.y.toFixed(2) } }
            },
            scales: {
                y: {
                    beginAtZero: true, grid: { color: 'rgba(0,0,0,.04)' },
                    ticks: { callback: v => '₱' + (v >= 1000 ? (v/1000).toFixed(0)+'k' : v) }
                },
                x: { grid: { display: false } }
            },
            animation: { duration: 1400, easing: 'easeInOutQuart' }
        }
    });
})();

// ── Transaction Modal ─────────────────────────────────────────
function openTxModal(saleId) {
    const modal = document.getElementById('txModal');
    const body  = document.getElementById('modalBody');
    document.getElementById('modalTitle').innerHTML =
        '<i class="fa-solid fa-receipt" style="color:var(--primary);margin-right:.5rem;"></i>Transaction #' +
        String(saleId).padStart(6, '0');
    body.innerHTML = '<div id="modalLoading"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</div>';
    modal.classList.add('open');

    fetch('../ajax/get_transaction.php?id=' + saleId)
        .then(r => r.json())
        .then(data => {
            if (!data.success) { body.innerHTML = '<p style="color:#ef4444;padding:1rem;">Failed to load transaction.</p>'; return; }
            const s = data.sale;
            const items = data.items;
            const fmt = v => '₱' + parseFloat(v).toLocaleString('en-PH', {minimumFractionDigits:2, maximumFractionDigits:2});
            let html = `
                <div class="modal-meta">
                    <div class="meta-item"><label>Date & Time</label><span>${new Date(s.sale_date).toLocaleString('en-PH', {dateStyle:'medium',timeStyle:'short'})}</span></div>
                    <div class="meta-item"><label>Cashier</label><span>${s.full_name || '—'}</span></div>
                    <div class="meta-item"><label>Cash Received</label><span>${fmt(s.cash_received)}</span></div>
                    <div class="meta-item"><label>Change</label><span>${fmt(s.change_amount)}</span></div>
                </div>
                <p style="font-size:.8rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin:0 0 .5rem;">Items Purchased</p>
                <table class="items-table">
                    <thead><tr><th>Product</th><th>Unit</th><th class="text-right">Qty</th><th class="text-right">Price</th><th class="text-right">Subtotal</th></tr></thead>
                    <tbody>`;
            items.forEach(it => {
                html += `<tr>
                    <td>${it.brand_name}<br><small style="color:#94a3b8;">${it.generic_name || ''}</small></td>
                    <td>${it.unit_sold}</td>
                    <td class="text-right">${it.quantity_sold}</td>
                    <td class="text-right">${fmt(it.unit_price)}</td>
                    <td class="text-right" style="font-weight:600;">${fmt(it.subtotal)}</td>
                </tr>`;
            });
            html += `</tbody></table>
            <div class="modal-totals">
                <div class="total-row"><span>Subtotal</span><span>${fmt(s.total_amount)}</span></div>
                <div class="total-row" style="color:#ef4444;"><span>Discount</span><span>-${fmt(s.discount)}</span></div>
                <div class="total-row"><span>Tax (VAT)</span><span>${fmt(s.tax)}</span></div>
                <div class="total-row grand"><span>GRAND TOTAL</span><span>${fmt(s.grand_total)}</span></div>
            </div>`;
            body.innerHTML = html;
        })
        .catch(() => { body.innerHTML = '<p style="color:#ef4444;padding:1rem;">Network error.</p>'; });
}

function closeTxModal() {
    document.getElementById('txModal').classList.remove('open');
}

document.getElementById('txModal').addEventListener('click', function(e) {
    if (e.target === this) closeTxModal();
});
</script>
<?php renderNotificationPanel($conn); ?>
</body>
</html>
